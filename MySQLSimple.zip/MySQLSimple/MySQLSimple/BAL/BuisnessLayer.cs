﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;


namespace BAL
{
    using DAL;
    public class BusinessLayer
    {
        public static DataTable GetActors() //Akash
        {
            return DataAccessLayer.GetDataTable(SqlStatement.GetActors);
        }
    }
}