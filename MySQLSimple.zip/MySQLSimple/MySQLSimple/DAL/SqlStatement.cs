﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

namespace DAL
{
    public class SqlStatement
    {
        public static readonly string GetActors = "Select * from actor";
    }        
}