﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DAL
{
    using MySql.Data.MySqlClient;
    using System.Configuration;
    using System.Data;

    public class DataAccessLayer
    {
        public static string GetConnectionString()
        {
            //string connection = string.Format("Server =localhost; Database = tekbytes; Uid = root; Pwd = root@123;Pooling=True;MinimumPoolSize=10;maximumpoolsize=50;", "tekbytes");
            string connection = ConfigurationManager.AppSettings["dbconnection"].ToString();
            return connection;
        }
        public static void AdaptTheCommand(MySqlCommand command, object param)
        {
            if (param == null) return;
            var pInfos = param.GetType().GetProperties();
            foreach (var pInfo in pInfos)
            {
                var pVal = pInfo.GetValue(param);
                command.Parameters.AddWithValue("@" + pInfo.Name, pVal);
            }
        }
        /// <summary>
        /// Example of param
        /// var param = new
        ///    {
        ///        @actor_id = 1,
        ///        @first_name = "penelope"
        ///    };
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        public static DataTable GetDataTable(string sql, Object param)//Akash
        {
            DataTable dt = new DataTable();
            using (MySqlConnection cnn = new MySqlConnection(GetConnectionString()))
            {
                cnn.Open();
                using (MySqlCommand mycommand = new MySqlCommand(sql, cnn))
                {
                    DataAccessLayer.AdaptTheCommand(mycommand, param);
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(mycommand))
                    {
                        adapter.AcceptChangesDuringFill = true;
                        adapter.Fill(dt);
                        adapter.Dispose();
                        cnn.Close();
                        return dt;
                    }
                }
            }
        }
        public static DataTable GetDataTable(string sql)
        {
            DataTable dt = new DataTable();
            using (MySqlConnection cnn = new MySqlConnection(GetConnectionString()))
            {
                cnn.Open();
                using (MySqlCommand mycommand = new MySqlCommand(sql, cnn))
                {

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(mycommand))
                    {
                        adapter.AcceptChangesDuringFill = true;
                        adapter.Fill(dt);
                        adapter.Dispose();
                        cnn.Close();
                        return dt;
                    }
                }
            }
        }
        public static string ExecuteScalar(string sql, Object param)
        {
            using (MySqlConnection cnn = new MySqlConnection(GetConnectionString()))
            {
                cnn.Open();
                using (MySqlCommand mycommand = new MySqlCommand(sql, cnn))
                {
                    DataAccessLayer.AdaptTheCommand(mycommand, param);
                    object value = mycommand.ExecuteScalar();
                    cnn.Close();
                    if (value != null) return value.ToString();
                    return "";
                }
            }
        }
        public static string ExecuteScalar(string sql)
        {
            using (MySqlConnection cnn = new MySqlConnection(GetConnectionString()))
            {
                cnn.Open();
                using (MySqlCommand mycommand = new MySqlCommand(sql, cnn))
                {
                    object value = null;
                    try
                    {
                        value = mycommand.ExecuteScalar();
                    }
                    catch (Exception ex)
                    {
                        value = ex.Message.ToString();
                    }
                    cnn.Close();
                    if (value != null) return value.ToString();
                    return "";
                }
            }
        }
        public static int ExecuteNonQuery(string sql, Object param)
        {
            using (MySqlConnection connection = new MySqlConnection(GetConnectionString()))
            {
                connection.Open();
                using (MySqlCommand command = new MySqlCommand(sql, connection))
                {
                    DataAccessLayer.AdaptTheCommand(command, param);
                    int value = command.ExecuteNonQuery();
                    connection.Close();
                    return value;
                }
            }
        }
        public static int InsertSQL(string sql, Object param)
        {
            using (MySqlConnection cnn = new MySqlConnection(GetConnectionString()))
            {
                cnn.Open();
                using (MySqlCommand mycommand = new MySqlCommand(sql, cnn))
                {
                    DataAccessLayer.AdaptTheCommand(mycommand, param);
                    int value = mycommand.ExecuteNonQuery();
                    cnn.Close();
                    return value;
                }
            }
        }
        public static int InsertSQL(string sql)
        {
            using (MySqlConnection cnn = new MySqlConnection(GetConnectionString()))
            {
                cnn.Open();
                using (MySqlCommand mycommand = new MySqlCommand(sql, cnn))
                {
                    int value = mycommand.ExecuteNonQuery();
                    cnn.Close();
                    return value;
                }
            }
        }
        public static int DeleteSQL(string sql)
        {
            using (MySqlConnection cnn = new MySqlConnection(GetConnectionString()))
            {
                cnn.Open();
                using (MySqlCommand mycommand = new MySqlCommand(sql, cnn))
                {
                    int value = mycommand.ExecuteNonQuery();
                    cnn.Close();
                    return value;
                }
            }
        }
        public static int UpDdateSQl(string sql, Object param)
        {
            using (MySqlConnection connection = new MySqlConnection(GetConnectionString()))
            {
                connection.Open();
                using (MySqlCommand command = new MySqlCommand(sql, connection))
                {
                    DataAccessLayer.AdaptTheCommand(command, param);
                    int value = command.ExecuteNonQuery();
                    connection.Close();
                    return value;
                }
            }
        }
    }
}