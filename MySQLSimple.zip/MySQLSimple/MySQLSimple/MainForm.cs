namespace MySQLSimple
{
    using System.Windows.Forms;
    using Utils;
    using BAL;
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            this.Overaction("Welcome to Sakila");            
        }
        private void btn_Actor_Click(object sender, EventArgs e)
        {
            var dt = BusinessLayer.GetActors();//Akash
            dataGridView1.DataSource = dt.DefaultView;
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape) Close();
            return base.ProcessCmdKey(ref msg, keyData);
        }

        
    }
}