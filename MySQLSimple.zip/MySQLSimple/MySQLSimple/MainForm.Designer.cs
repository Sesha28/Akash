﻿namespace MySQLSimple
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Actor = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Actor
            // 
            this.btn_Actor.BackColor = System.Drawing.Color.Transparent;
            this.btn_Actor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Actor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Actor.ForeColor = System.Drawing.Color.Yellow;
            this.btn_Actor.Location = new System.Drawing.Point(128, 102);
            this.btn_Actor.Name = "btn_Actor";
            this.btn_Actor.Size = new System.Drawing.Size(115, 34);
            this.btn_Actor.TabIndex = 0;
            this.btn_Actor.Text = "&Get Actor";
            this.btn_Actor.UseVisualStyleBackColor = false;
            this.btn_Actor.Click += new System.EventHandler(this.btn_Actor_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(128, 142);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(542, 343);
            this.dataGridView1.TabIndex = 1;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(887, 623);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btn_Actor);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sakila";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Button btn_Actor;
        private DataGridView dataGridView1;
    }
}