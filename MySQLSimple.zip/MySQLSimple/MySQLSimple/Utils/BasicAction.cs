﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace Utils
{
    using System.Drawing;
    using System.Globalization;
    using System.Threading;

    static class BasicAction
    {
        public static string nsAppreferencesFolder = "SlidingPuzzelDataPrep.AppReferences.";
        public static string MutexName = "{vsDFRJNK-46BE-4802-90B6-D3B75E489AED}";
        public static Mutex appMutex = null;
        public static EventWaitHandle manualResetEvent = null;
        public static string ManualResetEventName = "{E9B5129B-3CBE-431B-80EE-VLadhkbcAFS}";
        public static readonly Random rand = new Random();
        public static readonly CultureInfo ci;
        public static int Rows = 3;
        public static int Cols = 3;
        //public static List<Bitmap> splitMaps = new List<Bitmap>();
        public static Bitmap[,] Maps = null;
        public static String imgFileName = null;
        public static List<Tuple<Tuple<int, int>, Tuple<int, int>>> AllSwaps = new List<Tuple<Tuple<int, int>, Tuple<int, int>>>();
        public static string destinationRootFolder = @"C:\WOI\Data\PuzzlePath";
        static BasicAction()
        {
            BasicAction.ci = (CultureInfo)CultureInfo.CurrentCulture.Clone();
            ci.NumberFormat = new NumberFormatInfo();
            ci.NumberFormat.NumberDecimalSeparator = ".";
        }
    }
}
