﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Utils
{
    using System.Data;
    using System.Globalization;
    using System.Xml;
    using System.Text.RegularExpressions;
    using System.Drawing;
    using System.Net.Http.Headers;
    using System.Reflection;
    using System.Net;

    public static class Prompt
    {
        public static string ShowDialog(string text, string caption, string textBoxDefault, Icon ico = null)
        {
            //Prompt.ShowDialog("Welcome to custom message Box", "Wow this is nice", "<h1>Please type something here</h1>");
            System.Windows.Forms.Form prompt = new System.Windows.Forms.Form()
            {
                Width = 600,
                Height = 450,
                FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog,
                Text = caption,
                StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen,
                Icon = ico,
            };


            System.Windows.Forms.RichTextBox richTextBox = new System.Windows.Forms.RichTextBox() { Left = 50, Top = 40, Width = 400, Height = 300, Text = textBoxDefault };
            richTextBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Both;
            richTextBox.ReadOnly = true;

            System.Windows.Forms.TextBox textBox = new System.Windows.Forms.TextBox() { Left = 50, Top = 10, Width = 400 };
            textBox.Text = text;

            System.Windows.Forms.Button confirmation = new System.Windows.Forms.Button() { Text = "Ok", Left = 450, Top = 10, Width = 100, DialogResult = System.Windows.Forms.DialogResult.OK };
            confirmation.Click += (sender, e) => { prompt.Close(); };

            prompt.Controls.Add(textBox);
            prompt.Controls.Add(confirmation);
            prompt.Controls.Add(richTextBox);
            prompt.AcceptButton = confirmation;
            prompt.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            prompt.BackColor = System.Drawing.Color.White;
            prompt.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
            return prompt.ShowDialog() == System.Windows.Forms.DialogResult.OK ? textBox.Text : null;
        }
    }
    public enum IsFileInUseStatus { None, FileNotOpenByAnotherProcess, FileOpenedByAnotherProcess, FileNotFound, WrongExtension };
    public static class Helper
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 2;
        public const int WS_CAPTION = 0x00C00000;
        public const int WS_MINIMIZEBOX = 0x00020000;
        public const int WS_SYSMENU = 0x00080000;
        public const int WS_THICKFRAME = 0x00040000;
        public const int GWL_STYLE = -16;
        public const int GWL_EXSTYLE = -20;
        public const int WS_EX_LAYERED = 0x00080000;
        public const int WS_RESIZABLE = 0x840000; //WS_BORDER + WS_THICKFRAME
        public const int WS_BORDER = 0x00800000;
        public const int KEY_PRESSED = 0x8000;

        [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto, ExactSpelling = true)]
        public static extern short GetKeyState(int keyCode);
        public static bool IsKeyDown(Keys key) { return Convert.ToBoolean(GetKeyState((int)key) & KEY_PRESSED); }

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern bool AppendMenu(IntPtr hMenu, uint uFlags, uint uIDNewItem, string lpNewItem);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int
        SetLayeredWindowAttributes(IntPtr Handle, int Clr, byte transparency, int clrkey);

        [System.Runtime.InteropServices.DllImport("shell32.dll")]
        public static extern IntPtr ShellExecute(IntPtr hwnd, string lpOperation, string lpFile, string lpParameters, string lpDirectory, int nShowCmd);

        [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
        [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
        public static extern bool PostMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        public static extern uint GetCurrentThreadId();

        public static String GetRandomString(this Int32 length)
        {
            const string AllowedChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            char[] chars = new char[length];
            Random rand = new Random();
            for (int i = 0; i < length; i++) chars[i] = AllowedChars[rand.Next(0, AllowedChars.Length)];
            if (Char.IsDigit(chars[0])) chars[0] = AllowedChars[rand.Next(11, 40)];
            return new string(chars);
        }
        public static string ProcessExceptionHTML(this Exception ex)
        {
            StringBuilder strBuild = new StringBuilder(5000);
            Exception inner = ex;
            Enumerable.Range(0, 10).All(x =>
            {
                if (x == 0)
                {
                    strBuild.Append("<div class='box' style='color:red;font-weight:bolder;font-family:calibri;background-color:white;'><img src='data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhQUEBAREhUSFBoaGBcYGRYWGhYYFRMXFxobGx0bHSggJCYqHhgWITIhJykrLjAuGCAzPTMtNygtLisBCgoKDg0OGxAQGysjICY3Lyw3NzEvLTUxNzM1LzcuNTcwMDAtMC0xKzctNys3LSsrNTU3LTc3Mi03LS01Ly8tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAgYEBQcBAwj/xABCEAACAQMDAQYEBAIHBQkAAAABAgMABBEFEiExBhMiQVFxByMyYRSBkbEzUhVCQ2KCofBjcoPB0SQlNESSosLS8f/EABoBAQADAQEBAAAAAAAAAAAAAAABAwQCBQb/xAAvEQEAAgIBAgMGBgIDAAAAAAAAAQIDEQQhMQUSE0FRYXGR8DKBobHB4SJCBhQj/9oADAMBAAIRAxEAPwDt/T2/apUqPT2/aglSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBUSfIUJ8hXoFB53Y/0TXlTpQKUpQR6e37VKlR6e37UEqUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKiT5ChPkK9AoAFe0pQKUpQKUpQKUpQR6e37VKlR6e37UEqUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKiT5ChPkK9AoAFe0pQKUpQKUpQKUpQKUpQKUpQR6e37VKlR6e37UEqUpQKVBpQMeZPQDGSMgE+wyKxGuun9bP8p5f6eY/F0Gef9ZDM3jjkc9PvUWmUDOR5+Y5xnI/yP6VqbvU1RGeSRQoUlmDBQ4AJ+US4Ax/Wqm6x8U9MRij3HfnOG7pHZcYfaYmJ2hhlctnH/ILle9prRQf+8LOM5xl5IyARnIPjHoeM+VQj1WdQHZIrqE/2tsSWHUk90S2QB/I7MfJapMXxj09s9488RbcGHdt9GJNmzYxw53JljxwftVgtHs7rdPZzIH85bZgpbiUohXOGkwASsin1GOCAuEMquoZCGVhkEedTrW2F02CJAu5TyyAhH5b6QScNxypJIPmRgnYK4P8Ar/KglSlKBUSfIUJ8hXoFAAr2lKBSlKBSlKBSlKBSlKBSlKBSlKBSlKCPT2/avlLL79R0zk5ZOR/d55NSlfHr1A4BJySMeR455PlWlmnK87ZPAyg92rFlYm3ISHMeGhOcO/Qc8jB2B93uTxnceVzs3EknuOYeOY/F4j5c/etHrOuR28LzXD7I41BdoyQSdsO0WZPDIScP9yax4pZwfmQrGqNGoNuzu8an8L4bUG1AMJwu/BOMtyMDGmXS0vdQtbaSNNlmguZERR+HQ7I44Y7VtikxlgzMOQWjI8sUHmk9jZ9XK3WsFooD4oLGMsiqpHDP5gkc4GDz1H010bSdEtrVdttbwwgfyIq59yBk+5rYUoPlc2ySKVkRHU9QwDA/kaoev/C2BmFxpjf0fdJko0f8MnBGCnQZBIyuOvQ9K6DSg572Y7RSSNJb3kXcXluPmxj6XXxHv7fAJZ2Jq3W05yOD68hsbcr9Xh/i/wB2q/8AEjSV2RX6jEuntvLgAt3BG2bGQRuVC0ikg4ZPuakl0qYLhUH8TLgqhTcnz5GMAAuvPus/9QFsgkyB15GRkHOMD6uODz0r6E+Qqu6LqsU+38PJHNuVXyDncvycyTYiG2Yc4jOOnljw761fKr9WCoI3AqxGB9QIG089CP8AoA+oFe0pQKUpQKUpQKUpQKUpQKUpQKUpQKUpQK8Y1Xu3HayLTbfvXUySO2yGJfqlkPQdDgepx+pIBp1p2N1PUvm6vfzWqPytrbHZsB6bzyM/Yhz9x0oL9eMcgnePGqlghZtzPH8sfJOYm/rSeQzyMZXn3aLUbl7mLTdMVIrruwZZNg2WUGyEGKBjEuYiVXnBycDjjbsx8KoojvsdQv7aUKQGLrKhBxkOjDDDIGVyAce1OwOmXFvqN2L1I1c20CwNGAsTQwl0IiGBtAzFlDyCR5EUGvtvg93aoy6tfLNGu1JFICpx0VM7gvTwh+grI+FthcW15fW95sMkMFssRRVRGhDXGGjVQAAScn+8Wq6drNbWxtJrlgG7pCVUnbuY8KufuSK49bXt1LILmfX2tpSuPl2U7wom7cE3lFQqD5+L3PWomYjuO8UrRdj9SaeAF7y1vGXjvYOA3+8mTtP5/kK2OrapDbRmW4lWJAcZbzJ6ADqSfIDJNSMylUybtLeXH/grVYIz/b3e4Ej1SBSHP+Nk9qxjo88nN1qd7IfSJltUHsIgHx7ua87P4rxcM6m25+HX+llcVpb7ttf91aOqwmeS5+RFCP7R5VIwfQBdzMfJVY1TdG+EML5k1WV7ueRi8gUmKJXfG4qE2kk4GW4zjOKzpOzjKQ9rf3sUqA7Wkla5QEjHKTbhz9sH719+wvbWSaeSw1GNIbyHJGzIjnQc7kz54wceY54wQvfE8Qw8rcY56x7J7otSa92Lqnwc09gGs++spkIZJUkkfa6nKkh2J4OD4Sp461sexOq3Pey2d+qi8hAcuoAS7iYoiz5C/UAu3HH/ANbDr2uw2aBpmOXO1I0BeSVv5UQck/5DzwKpes3+pTSRz2+m2kbRBgnfzbnKsVbDKg2jxJG2N5wUHNaMvIxYtepaI375cxWZ7OhvLgZwxz6A5/SseLU4mYJu2ueiuGjZsddoYAt7jNcqX4uXdo6x6rphT+9G2C2OpUHKN+T10PRdbstUgJhZJ043IwwyN1G5TyDkZB+2QatraLRus7hDfUrRRzPZsqTO0tu7BY5XO54mY4WOVjywJIVZDznAYkkMd7UhSlKBSlKBSlKBSlKBSlKBSlVWftsjMy2VtcXu0kGSPYkIIOCBLIyq2Ofo3dK4vkpSPNeYiPimI21MNj+N16aSUbotKijSJT07+de8L+4Uge+w+VdArnugdqIYLy4W9jlspb+dHjEu0o223iiwJUJTO5DwSPqHmRU+096by6a0DEW1uB34DFO/lddwiLDnaqFWYA8lwPI1Xk5OOmKcu91+H8JiszOl1j1KFm2rPEW/lDqT+mc193QZDEDK5wfTI5rjOo6jpf4lLA6fbhyQpYRRbUcjITcBuyR5jzI++MTtVd3enSi2tZ5Ht9RiMSxyO0n4d3IizE7HcMbwQM+v2NZeP4jGS8UvWazMbjfth1bHMLjZML+U3s4DRKxFnGeVWNTjvyDxvcgkHyTbjqa+Wt9u7W1uI7eVn3vjcVAKxbjhd5J8+vAOByfKsp7kQosaIAsUYGPJFRQAPyAFc07DaX/SLaleTjO6N0XOOGuI3z+aRhV9nrxuNxp8Rz3yZpnUdvz7NF//ACrGu679uez4aNruzzb3lspdZIvCzheWR8fUCBxnPIA6Eg/LSO1H9J/0U7hd8f4l5QOglgjjiBA+4uN49Mitt2ZvjPawO6/xYY85896Ln9zXNPg/GUu5xkkQxMoH955olJ/SMfpU8TNkjh58Vp/D0j8+iL0iL1n3uyPLVAi7Y317cy2+lWcT9yxDSSv4cBiu7AK4BIOOWP2qw9pdSMFvNJxmONmGPUdB+pFUb4Ra2LS3uO4ha4u55VUDlURI04aV8YA3PIcDLHjjzFfhHDw3rbLmiNR7+332WZ/NGq07yu+iXl9Hcm21EWZYwd8DbmTwDvAgWQOOp8RGP5GrQ/Fu1aMWt/b+Ge2mVQQMkhssowOT4hjHmHYedb/Rbd0LzTP3s85DSyYxnbwFUeSKMhV9z1JrSal2gjutRtbKMh1glaWU5yDJEjlEHrtPiP3AHka4pasc2cvHrqtdzPyiOv19iL45ikRbvKyaRaOXN3eYa6lXGOq28Z5EMfoB/WbqxyfSsXtR23trDAmLO7DIjQAtt/mOSAB16nnHFZWpah3aO/BEasSM8naCT+1cl0LSGvIptQuiHMl5BAM9A0ksRkb2CFY19Nx9BU8Pizzcl82eekfevknLEYqxWveXadSsIbqIxTxiSNx0PUehB6gjyI5FcU7L6XdQ3d4dPkb8TpzOQvUXEKSlJEZR1PCNt88nGCFI7PHchVMjthUUs2fIAEn/ACqk/AhDJNqF9J4Qxxk9AZHaaT9B3f61q/4/54nJG/8AHp9VXJrqYb2btYmsW9tBBlRc5a8UHmKKLG+IkYPzHZFB803Himo2N3YAz6XM7xxgl7KZmkjZRye6LEshxngHH7H5dirWJfxF1FGIxfzNKq9MQ7j3ftkEyY8u8x5VgfFTtQbe3FvCT310CvHVYzwxGPNj4B7n0qM3Nz5efFME9I6fD4zJ6UVx7s6J2N7UQ6lbLcQZHO10PWNwASp9eCCD5git5VS+GHZY6dYpG/8AFlPeS+gdgAFH+6oVfuQT51ba+mZSlKUClKUClKUCsbUrwQwySsCVijZyB1IRSxx+lZNRljDAqwBDAgg9CCMEGgo/xJ1SdbRYUbupLhV71052I88EDKpPQkzjB/lV+hwRVfilq8tha262TdwokC+ALwiRsQoyCMcD9KvPb3Q3ngcwgs6wOqr6urxTxH14kgVf+IT5VRviBbDUNME0I3AKs6gdcbSHHuFZ+PUV43iUR/2ME3613MfDc+9owxuttd2bc2p1O0ltbxUS5hOCRyqybN0cqee11YHHozL5V8uxiMmnI0h3vumabect3iyuGy3JyAoX8q87P6ms5025VhuubV7Wcf7a0AkQn77e+Psw+1bDS7bc2pwr0/EHH2M9rE7f+5ifzry+dj9C18Efh3F4/af1n9F2K0Tq09+zm/ZGw761vr9wDILm0WM+jyXsUkmPyZB7Zq4/EUePTZDjcL+Ifbrn9wKrnw3uN9qLDBEraik0q9CsNvHGxJ/4saJ7tWZ8WZnnurOytzmXcGAHlJKwWPJ8sAMx9Ac16nLr6nNxY6+yJ+mtKaTrFMyt3auGRLO7cEbu4kJPoBG3StP8M1EWgXc3HhknkbP+zgCgD/0j9atenXC31rlhtMitHMh6xyAFJUI9Q2R7YPnVF7GabeJbzaVNbSqjXYklmIxGYVCbkQn6i5jUYHk7Zx0rJ4RyKYKZa5Z1NXWf/Py6W/s9atb2kSuRiGFOT5bIwTn9DVB+CqGSW8k9Viz/AI5JH/8AiatfxT11bWyeMMO9ugY1HmEI+Y3sF492FYXwc0p4IrrvV2uZYwR5jFukm0/cd7gjyOax4/NHBzZrf7zER+Uu72ickRHsWfV9OSdSkqB0OMqehwysM+v01or7UbSxXEskUWBxGo8XQDhFGfzxitX8Sr+d76zsbeeSLvyofuyVPzphGpJHPAVzjPvV00L4T6bbHe8TXT9S053jPrsACfmQT9608Dwu2bFW97arPXUff8LLczyTqsdVAt9R1HV/laZA0Fuch7hztyPPxDIHptTc33FW21+FSWlsptGV76KQSCV/CHKggxAc7UZWZfXJBJOBXS40CgBQAAMADgAfaqM+v381zcxQPZ234aTaI5Y5ZZHT+rKSJEAV+owD6ZzkD2ppxuJhncar7e89/exTe+S257tba3qXAdNm2RMiWGTiSIt1Vx6HPDDgjpVdsbN9LSeF7c32mXJzJGue+hbAG4Y5YAKvI5G0HgjLb3W9SSR1Gr2slnInEWoWpZ0H2YhdyqSfokDL1z61LQdaDT/hWuLW7buy6T27oyuqkA94isTG/iXjlTng8YryPJfhxOfjTF8ftj7+/fDX6tctfJkjUsSfs/c3tiy6VqcF1byqF+cGEqL5oZF5zjgh03YPXzrIuNE/o/TINMDKZr+Ru/ZM/RgNcMMjONgSEE4+pelazt1anTduo6e4t5u8VZYx/DuQ2Th06E9Tkc4yeCM1tNK1YahdSXLDZttoFijP1Kk0azu/szMEyOvc/kNkczFXh2z4a63+/ZTWk2yxW07ZU98kKMzkJHEpJ9Aqj/oKqnwv0p9U1GXUblflW7ju1PI7wDMa/wCBSHP95lPrWN8Tbx5JIdPthuknZSwHnubEan3PiPoFHka7N2U0JLG1ito+RGvib+dzy7H3Yk/5Vz4NxYpj9ae9u3y/tbzs0Wt5a9obalKV7TCUpSgUpSgUpSgUpSgVRNQ02SwlkeKGSezmcuyRrvktpHOXKoOWjYksVXJUk4BB4vdKo5HHpnpNLx0dVtNZ3D8/DWdLsblpLH8VcSlm2WgV444pXXYxw6BgcZXADEA4xjGM7s92e11Wm1ECGIz5eSCbfukVVyoEYGQQPCoLK3rXbpnRAXcogA5c4GB9yamjggFSCCMgjkEHoRVdOFiiJ827bjW7denuJvLlMMOqsDNYWOkn8SA34mNziQeTHIVj1PXODWw+H3w6ltrhr7UZlnumztC5KoWGC2SBlseEAABRkDPGMrU+xt5byPNol4sAkYs9rMN0BY8kpwSmepAH5gcVqZtM1+7xHd3ttZRMPGbcHeclRsyeQx3cAMM1Zh4uLDMzSutk2me52nmSXUGGmXK2sse38ZcZDQFiwSOFkY7GlPIB4Ph2567dXfanq4UbbmzQbCZC8axNbvtUpHNl2VHfeAoJOa33ZrToYEWGyCbI2G5pM92rMbUutzhtrXW7dsC8JwMDgH6rCfBjjAXb+JLFVBW1yNR8fM/J7r8qjJxMGS3mvSJn5EWmO0td2M+HcdxIl/fXp1Bjgqu0oqshPhdSc5Vsju8KAQcit1JaXVi85W1e8gmnkmDwle+QytuZXjcjdg5AKknAAxxVTha706VrjTxJJDLhprW4YiRSE3NJdSO5EczswCYGHUL1I5vfZ34iWN2dhl/DTg4aCf5UisOqjdwT9gc+oFM/FxZ8fp3jp9CLTE7hzzQopL3tGk5t7iOKBc/NjeMgJAVGQw4PeOT+VdwrwGvHYAZJAA6k8AVZix1x0ile0RpEzudnT2/auW/EHVhb3GL2OaPaC9rf2wVniQkbo54zwVDELzkMCv8AWyRY9Z+IVsjmCy/7fckHEUJBRcdWll+hFHmSePSsfRrGYEyXLb55WHeMoZeVYhUUH/ygB6/1iWY/VXdqxaNT2QqegfE0TSGH8NNdsoz3lrG7blHVmibDr9xlhnoTWdP28tosiKwv2cnlVtihJ++cf86t1/oZlQd1K1tMh3RzIMmOQhAdinhoSOqHg/YgEaeftHrVp4bjSY71R/bWsm3cPL5bBmz0z5eleVbwXizbepj4RPRZ6tnOe1VjqmpKLi5tzZ26OkcUcm5SXnlWIEggMTlgSxCgAeHqc2ntH2NuDGk0V87zWkRWMFEhUIADsjMIUr9IADFx5HqTX21rWdX1SJ7aLRPw0cuA0ty5GzBBDAEKQQQCCA2CAcV9bzsrqk8Rto9XicKoSdzDtbcR4kDqeeOvCtgjJ5rvPxc8eSnGmK1jvE/c7K2jrNmv+DOiR3UrapLcPNOpZCjoo7uQqBu3A4b5ZUDCrjLcV2Oq52E7JR6ZbdzG5kZm3yORjc5AXgc4ACgAZNWOvSiIiNQrKUpUhSlKBSlKBSlKBSlKDVdo+0NvYxd7cuVBYKqgFnkc9FRRyTWhu+3TrbyynTb+AiJmi76MBWcKSivsZimTgZYAc4zmsXtW0cesafNeFVgEMyRO/CJcsVPiY8AlAcZ6leOlXW3uo5lbu3SVclSVIZc45GRwfuKCi3fZrVYojcx6vLLdIu9oWRPw0hA3GNU4Kg/SGzn28rh2duI5LaJ4l2LLGsmzzTvh3m0jy+rpWwdQQQehGPTrXN+0OnW9lqOmf0bFHBPLNsliiAQSWu0mR5FXg7cZDHz9ccB0eaPcMbmX7jGR+vFaa77Oxy8TPNONwJV3KxnBH1JGFVsYyAwIyB6Ct0T5CvQKDTQ6eECJGi7VC7VYYRlU243SALjvBtOz2/TBWzJ24XdkKR3oOJQBb5a78H8UY8HsPysjRA9QDyCRgckYwT9xtGPasV7Ieaq+SMhguJCvd4d/B9Q28Y9B+QVk2GQMLv3Djvw2JcKmTfeD6lx8v8q02u9koLwL30JkYBu6km7yOQnEhIvXVAyoMDu+ecAc+d3exB6qH3AZ3qMTYA5m+VwVx4favjLp4YNlBJ3gIPeKPn4D4W4+Vwq58P8ArIczf4aBN/4G81C3VgwhVnkQLIvfFjOFiGyM92u1+d2fuM5DfDGF2JnmvrscrGtxJKo75BPkzYi3JEe7XbKDzu+4z0OXT92/K973m5T3iqPxHFxiG4+RxEu7wt58dc+P6yacG3ZHeb9ytvVMzr/2j5E3yf4K7/Cep++TvDSaJ2agtUMdrB3aM7g5U7pH3TAxzExZMGMBWJORjk8Z38Nr9j1xnHPX+GPB/C9KyUsxk55zwSQmWXL/ACz4PoG7j/8ASclYwPL7dB09Pag+UMQXHA6Y8vCOOBx9PH+vLy6ty/0yyRH1Xaf8nVl/PGayKj09v2oNTJorufm3t06HqimOEH/FEiyfo4rZ2tskSKkSKiKMBVAAA+wFfWlApSlApSlApSlApSlApSlApSlBVvigJf6KvO4GX7r0ydm4d4R99m85rZ9nNVtprWOW1eMQbBjGAIwB9JH9UjoR5YrbEVTn+F+lGUy/gkyW3FQ0gjJH+zDbMfbGPtQWXT7+G5j3wuksbErkcg44PuCOQehBBGQRVO7FQQJqepx2scexDCTIFBZJJFbvIg/UqNqnbnCkkegGV2g7P20spLpfWzkBTJaGYCVFGFD9yCOBhfEoI6AkAVvuzWh29nAIrSLukJ3HO7czHqzlvETwOvoBxjFBtAK9pSgUpSgiUB6gc9fvXjRg5yoO4YPA5HoanSgi0YOcgHIweOo54P6n9a9x517SgUpSgUpSgj09v2qVKj09v2oJUpSgUpSgUpSgUpSgUpSgUpSgVEnyFCfIV6BQYt3p0chBbeCPNJJIiR6EowJHXg+tZKIAAB0H3J/zPNSpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQR6e37VKlR6e37UEqUpQKUpQKUpQKUpQKiT5ChPkK9AoAFe0pQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQR6e37VKlR6e37UEqUpQKUpQKiT5ChPkK9AoAFe0pQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQR6e37VKlR6e37UEqUpQRj6fr+9SpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSg11KUoP/2Q==' /><br/>");
                    strBuild.Append("Process  = " + System.Reflection.Assembly.GetEntryAssembly().FullName + "<br/>");
                    strBuild.Append("#################### Exception begin Thread id = " + GetCurrentThreadId().ToString() + " ####################<br/>");
                }
                strBuild.Append("---------------------[" + x.ToString() + "]---------------------<br/>");
                strBuild.Append("Message : " + inner.Message + "<br/>Stack Trace : " + inner.StackTrace + "<br/>");
                strBuild.Append("---------------------[" + x.ToString() + "]---------------------<br/>");
                inner = inner.InnerException;
                if (inner == null)
                {
                    strBuild.Append("#################### Exception End Thread id = " + GetCurrentThreadId().ToString() + " ####################");
                    return false;
                }
                return true;
            });
            strBuild.Append("</div>");
            return strBuild.ToString();
        }
        public static string ProcessException(this Exception ex)
        {
            StringBuilder strBuild = new StringBuilder(5000);
            Exception inner = ex;
            Enumerable.Range(0, 30).All(x =>
            {
                if (x == 0) strBuild.Append("########## Exception begin on thread id : " + GetCurrentThreadId().ToString() + " @ :" + DateTime.Now.ToString() + " ##########\n");
                strBuild.Append("---------------------[" + x.ToString() + "]---------------------\n");
                strBuild.Append("Message : " + inner.Message + "\nStack Trace : " + inner.StackTrace + "\n");
                strBuild.Append("---------------------[" + x.ToString() + "]---------------------\n");
                inner = inner.InnerException;
                if (inner == null)
                {
                    strBuild.Append("########## Exception End on thread id : " + GetCurrentThreadId().ToString() + " @ :" + DateTime.Now.ToString() + " ##########\n\n");
                    return false;
                }
                return true;
            });
            return strBuild.ToString();
        }
        public static System.Windows.Forms.DialogResult/*? I tried this*/ Show(this string msg, string caption, bool toShow = true, System.Windows.Forms.MessageBoxButtons buttons = System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon icon = System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton defaultButton = System.Windows.Forms.MessageBoxDefaultButton.Button1)
        {
            if (!toShow) return System.Windows.Forms.DialogResult.Yes;
            return System.Windows.Forms.MessageBox.Show(text: msg, caption: caption, buttons: buttons, icon: icon, defaultButton: defaultButton);
        }
        public static IEnumerable<T> OnlyCountEquals<T, P>(this IEnumerable<T> e, int count, Func<T, P> GroupByWhatField) where T : class
        {
            return e.GroupBy(x => GroupByWhatField(x)).Where(grp => grp.Count() == count).SelectMany(x => x).Distinct();
        }
        public static void MoveFrm(this System.Windows.Forms.Form frm)
        {
            frm.Capture = false;
            PostMessage(frm.Handle, WM_NCLBUTTONDOWN, new IntPtr(HTCAPTION), IntPtr.Zero);
        }
        public static void MovePanel(this System.Windows.Forms.Panel pnl)
        {
            pnl.Capture = false;
            PostMessage(pnl.Handle, WM_NCLBUTTONDOWN, new IntPtr(HTCAPTION), IntPtr.Zero);
        }
        public static void RemoveFlicker(this Control control) { control.GetType().GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)?.SetValue(control, true, null); }
        public static int s = 0;
        public static void Overaction(this System.Windows.Forms.ScrollableControl TheControl, String txt, int xOffset = 10, int yOffset = 10, bool showImage = false, bool holdRotationAt360 = true)
        {
            System.Windows.Forms.Form frm = TheControl as System.Windows.Forms.Form;
            if (!String.IsNullOrEmpty(txt) && frm != null && frm.ControlBox) frm.Text = txt;

            System.Drawing.Image img = null;
            Action LoadImage = () =>
            {
                if (img != null) img.Dispose();
                if (s > 4) s = 0;
                string imgBase64 = "";
                switch (s)
                {
                    case 0:
                        imgBase64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQEhUSEhIVFRUVFRcXFRUVFxUVFhUVFRUWFxUVFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGi0lHSUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBFAMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAAAQIDBAUGBwj/xAA/EAABAwIEAggCCAUCBwAAAAABAAIRAyEEEjFBBVEGEyIyYXGBkaHBBxQjUrHR4fBCQ1Ni8XKCM0Rzg5KTov/EABoBAAIDAQEAAAAAAAAAAAAAAAABAgMEBQb/xAAzEQACAgEBBQUHBAIDAAAAAAAAAQIRAyEEEjFBURNhcaHwBSIygZGxwRVC0eEUMyNj8f/aAAwDAQACEQMRAD8A8VambmPw91EFTad0kMk52379UdZaP35KB8UItgJxlSbzSIukigTDVMC6SkwpgSaFZzSp/P4JvfeEARJV1NuyoGpWRQKVjomP0UxTVVN4J9VmMIRvMaiijInkVzkJqTDcKMqMquSTsN0pyqbWq0BBaouQ1EGAbq9tBh1sqGq5irnFPW6LYTa0qyFXCDYyqKmHI1Wzp0zyVzqFoc1Udtuurv7l3Yb64UaLq1HItpWwRbsYWLUokLRHNGXBlEsMo8UYhCRCvyFI0yp75Xusx1FZDmqshWJkJIrSUiFAq1MqaBEoSTESQooSFRjGysY6AqypxH7sspeR1TBQ5IBA6GLqRHJOmPTdSaRef3+aLCipSCIBcrHsyp2FCGkKIU8piVANsSi7CgbzVzTb091WGxqP1VkzoNPidglY0i2gQFmUBZY9GiToPZZjMO5UymkXwgwLVW5qyBhzyKmMI47FVdqkT7OzBc1QWxOAf90+yrdgX/dPsrFnj1IvBJcjED1MVFZ9Tf8AdPsn9Tf9x3sVPtYPmRWOXQrzqylUCRwrh/CfYoFM8knJNaAk0zPpVANH/ArNoYw/2laqnRPJZLMO7kfZYskIvmbsWSSM2vip2HusGvDlazCvOgPss/B8Grv0YY8R+ao3oY9bou9/JpVnPGmUDDvOxXXDgT295oHmQPmlV4S5t8wHqPzUv1GPKhfp75nHVMO8bFY9SmeS6LHYcjcehWpqhbMO0uSvQx5tmUXzNY4KJCyajFUaZW+OSzFKDsphKFcWJZVPfIbpVCFZlQnvIN0xapk8tPFOo6Yt7KDjdBCzkiTTCkTAI5qsJtklJAXlvZmLD8FEN+G/5lX9eQIMEzf9SscvOm0z6pJsskooQEH03UqTQTfQ2t8SouqGb3hIck2Q0svgExMgctz58lPqwbSLEc4MkR6QSoS0e2+vskKpIvEEgnz/AMKOpPTmZfZuSRmmw1BuOyCthgMOJmMxi47uV25g3gSPdYGHpZ3ZT/DbMTYE6bX3+C29HDPaZYbt0kGPib8lkzSSVWa8St3RtaFOm49pgbGgBMnxk7+i2AZRboz3utM01Ce00A8/19FkOdkmT+/RcycG3x8zdHJWteRsxXb/AE2+36rKoY1o/lt/FaRtcLNw+ICzzx6cC2GWXU3bOIN/pM9ig4tpN6LCsFjwpthZnCKL9+XUyvrrBpRaI5LExHEDsCPUfkp03XI8vwVv1YnYI9xPVD3ptaMxW8VIi5We3jFLcT6D8ljVMDOjL89fgmOFm0NTaxME8vUzaXEaeuT4AQrW42mf5LfM6qeG4VI7rZ9Ss+hwqP8AAWeUsa4Fly5spZiRq2k0e6hXrVHCA0AHkFvMPgQNlkHh/gqd5J8Ct5orRs4yrQcdW+8rVYrD30XohwAjRVDhLfuD2lXQz7pGU4SPKMdh42Wir0l7JxTgzAJDQD4Lz/jWFgmy6mybZbooy7OpR3kzjqghVFZ+Ip3WK5gXdx5bRyMmOighRLVdlRlVu+ivcKYQrMqaO0Q9wwsJQLz5mPcEn2F/RZmI4RUbBawkE2Ikgrpfo74RTxVOu00w9zC3VzmtAdoJAMklpEWsCuownAhTY+jU7BpOvUYLFhINNzxN+UkFstN5ELm7T7Q7LK4JaqtPHn18jVs+yxnBNvj68DyoYNwMOGWb3tAiVXSYQ+GiToPVdt0mwlHCiowlrakSzsl2e8mQScgMARoC4emp6K8Fr4lzxTpMe4sFT7XMGwS8CA2ZLhmiYiJCujtkXheWWke/S/r/AC68SEtmSyKCev2NOcGWzI0/+rTb9FXiKQY1pm51byI1nks7ibalKGOqXaXSwNALHMc7XebDXmNYtWeG52uezM8i5IBiDN3EgAQVfHJopN6ekQeO7jFa/Lx5WaslJoUQiVpMl6jcpMcoISCzeUatIMbDoLLnUF1503Kqx/Fy4tyyALx4g289lqJQqVgjdvUteeVUtDfUuklXctmbdkaLf4aqa3bYARA/2jafVcEs7AY91OwJE2JGseE2CozbJFr/AI1TNGDandZHaO7o8OJHqsynwvKC5xAAuSTAA8SVr+jnE2nJmJAdYkOt1ki8Ha+viBsuY6V8SfiMQ9rapqUmuimATlNhcDczN1zMeDNlyvHdLm6+X1+Z0smbFhxqdW3wOwPSTA0g77XO4AwGtecxGjQ6Ivz0UsP0wwBaC7OwkCW5XOgkgESBeASf9vkvM30XNs4ESJEgiRzE7KJYtv6ThfGUn81+EYv1LNeiS+R6Zh+lfDy50vqMBMAupyIG/ZkwVt+H9MeHF+TriNg97HtYfUjs+sLxvIjKoy9j4Zful9V/Afqebu+n9n07g+HtqAOYQ5rrhzSCCOYIsVmjgngvnnoX0pxHDq7XU6hFMn7SmS7q3iI7TRMHTtASPHQ/S/B+M0cVRZWpOBa8T5HcEETK4e1+z57NLWVxfB15PvJ/5uWStGHR4RGyy2cOCzTiBzUHVRzWFxXUg82WT1KWYMBZFPDiEmVG+PuVkU6wU8WPG377opnKZScOBoFU6hGy2AeE7FansUJ/DNevmQ7SS4nN8QoeC8+6WUCJysN9V7DWoNcLhaPiXC2EHsE+ip7KeCavX6nR2Xa1W6z55r0XSbFYxwjjsV9AYbo3SfrSAHMgKnEdGaYOUUhHMCy3x9quK+EbhhlLd3vX1Pn80jyR9Uef4SvdavQ7DEd1gKTODUaQy5W/BT/WVWkRR2bE/wB3kfPr6NQnstEC3t6oXumH4VhKwzim3UgxAuDeRzTV36x/1sHsEb+J/Q8t6A8XOCxDRTBqmvRjIwT9qHkgOiSAGgyQ0m9gV3dd3XObWr4hzJADqNJlfD5qJILx1tUB9QjKXgNDTAfAuV5fhcU/DnC1MoLqby5knOwgtY7LDTPmP7l2eE6ehjftWNcRSI7YaXOacv2RYLHQGSNtputt2ec8nawV3fR3q1py4Ja8eJnwtbu7J1/4ir6Rvqja9LBYfq205FXEdUO04wSxmYXqPLSYBky4XusvhnCXue41KtSg+pDnCnamykGsdRpF8ZHuAeSbfe134vo7jaNJ7qtVoD3HNTcB3IMxTbEAk2Dv4chgCQuo4p0zfQptZTDatN3aa9zWECT22CO64XGh1HijNs2SLjhhb6t/ufFvnw4a9F0bcsE1uucn0+S4ePX6+Bo+k3AOoxLmMqtqimGurVS0hrH1ScjXxImA3taXutJi8UGgsouOUjtkiC6YORxGsQBP+q8FZnEOJvex4LRnrPNSqAPAZSCDoNZP8RdzK5+V1dmxzcV2rutOWve/nddFXPhmzT3dI89fX5+YlJo8YUU3LaZBwlKyKxbAgQd7zoBceBn8VjFJOxyVAlKFJo9t0EQVlGkXGGguPIeCsFEEdk3nk6IM6TsPHn6rb8H4FUqPbeBmEOE3kHKBpqREzz1gqrJljCLbdeJdDDKT0Rteg/BKVWo51aq1rGgyw2JMkN1tAdGq5Ok51J4cIzMdOxEtPhYiV6IOAHCNrF5AIYTTfMy7LfvSNI22G682bT0uNFk2TKss8kt606VcuD9O9TRnxuCgq6vzRlYrHVK7s1R5cdBNw0EzlaNh4LtOif0dVuIUXVmFrWt572NlwdOy9G6G/SD9Rw9XDupF/WSGOzRkJBseas2hTjFLFou7wfDR865cAx023Lj3+PicJxPBmi9zDq0kH0WCT5LP4jXNRxcdzPusMU53AWjG5bq3uJVkjFye7wJUaDnyACYaTYE2G9trhez/AEVdNsIKVPCVC5tZz2tYMpLXdhjZzCwu06rzDolUyVah7w6h/wCLVhua7B12Ppu7TCyownke02fTy1WPaccdp3sL4pWteffo9OBasbhiWTk20+7p+T6eb0jwJ/5vD/8Aup/mtjg8TSrMFSm9j2OmHscHNMGDDhY3B9l8jcRxPW1alXKB1j3Py8sziY+K9Z+hbjBh2DqPDWkCpTJ2Jqhrma6GQffmuTtHs54MSyXb0tVVXx17vkEKySajwXPu9antTMvIK5sLXZXaMfmMTt7rU4/igokhzyXC2UG8xN9twscM08XGPr5BHA8jqL+51QQYWjw1QVGNcKh7VrnunYOI0JU38Ne+2cWMHtb8j4rYtozSXu4m/Pv5Lp64kXgjF1KVfI3IqgLHAph2bKJ5zz1WtrYPqaTqlQl2W+UEQfUrluIdMGZHNLGNI7pBgjnM6qOTPnVLJFJ8Ut235p1w9crcWydpbxy04N8Pzqd2/HM5j0IVL+IU8pOYD439rrwSp0tLK7qmYmTMNJAy3dmE62WLxP6Q6nXE0s2TW5APdHpY5vdTcNtyPRLVX0+xY9lwR+KZ6HxjppQpVCC8utMiDtpFrrz/AI59IVSt2WEU23IdBc4kXaCBoDpy1lcVi6/WmST5nU6yT4rAIW3ZvZOGGstX3iy7Y1pjVI6fB9J8TRBFOqIc4uMh7jJtcixMAIXM5h4+6FtexYW73fJfwUf5WTqWNxB7M9oNNmuu2LWhFasCLCO1MbDXTfc7qkhSySQBcmPcrVuq7MlsyKtYFjWgQQL631M3NvTmVT1xgN2BmIFyNz4rIxuFyRMbTHNYiMe7JWiWRtOmNzjrz1VYUimpPRlfHUgmkU5QMAkiVFArJSmCohNIdl3WmZ35zc+a6foz0oOGe+o5udxBLSbkPg3iRz9JPNcnKk0qnNghljuyWhdjzSg7TO04508r4pnVuZTEF3a7UkPblgiYmN+a5bDYQvsAqqRuvV/or4fhq9eXsDQBoSSNIN3Xv7LJk3Nkx/8AHHn5vrfA0Qk80vf4JNnmVTCObEjUW/H5qoNheyfS1wrDUQ3qcoMbXsNhC8jZ3ud9IspYM7yJ2tU2uNrTo+Y541o1wYUcI54sPRRxPD3N1H+F6/8ARngsLWqufUYxgOlMHsgEaCTKX0s4XCUyBSDZIvCzLbpb9Uquqv3rq+HRdSSwqqd71X3eF9TxrCuyOMfdI/BGLqOqGSZytA8gBExyTxAglYzjBkGDzC6kVb3jPKTUN3kVrddGeJfVqzXbOhrjpAL2umfAtHxWnc6b7olPJCOSLjLgyqE3CW8uJ7TT4vVF2PIBGrSRIPiDdU1McSZJJ9ZXnnBuOmm0U3OIA7p1AH3Vsjxtp/mt+I+S8/L2dKEqo7MdsjNXep2tHjT6bSGuPa1GxHisOtx+sJEgb3d8YXJ1uOBrSRUa7wn81zGMxr6ri5xN9pMDXSdrmysw+zFN+8lXevxoRybfufD6+Z2+N6cVD9n1tgYtJA5mVznFeImoQc0k3Bn8QdFoibfvT9lJoldTDsOHDrBUYcm25J6MyH1c3nuoZCdifFGbKZFjy/RQL5WlLoZm74mQylOpHOx289AnjKJZElukiD8lSamkHRVyindknKKjVaghCFOimiJQ15BBGqcJAJ0RJueXd4z8kikFJNKgepEoUlEoAikpEJQkAkJwgIAAEJhNIYlIFEIAQNFlN0Lb8K4u+iczXEHb5laQozKqeOM1TLseRx1RvuJ8cqVwM7i4gRfcDZarrjqqc1lHMlDFGCqKpEp5nJ2zc4Hi76V2uIPgjiXGH1oLnEmN1ps6C5R7CG9vVqPt5bu7ehM1NVU4pEq3NbujTW86+B/FXUU2VhMpMdGwPmlKkRJBZ+F4cajcweB4GbQte1W0q7mzBidVGe9XuumSju37yMx/Cni+dkf6iPksBzYJHK1tPRXfWHOsSb/v5LHKIKS+J2Ke7+1UKElIpSp0QYoTKaiUAJSQGppisJQkhRHY0IlCnYgTQkiwBCSClYDKagiEWA5QSlCISsAUwoQmiwLEkFjhqCPMFRSsdEioIlCQ0GZEpEITokEppIQAIlGVPKgQkKUKynTJkgWGp0A8yhuhLUrARlU5A09/yHzUEA9AQpB0GVOrTiCO6e6fl5hF60DWllRKScITtkRITKSSAadlFCnvIATSlNK0BGFKEs3glmUdRjTUZKJKBE4ShRhEIoCUp5goIlFDHKlm8PefkoyhFATzHw9vzUmVXfeI8jH4KuE4RQ7L3NDrvqydrOcT6mB8VQ4DafW3wSQhRBsycRWYYDKTWQNcz3OPiZMewCgKroAsAOQaD6uAk+pVaEboWwIQkhFCsaSEBMATa2SALk2AGpOwC2VDhLsvWVXClT+865dzaxgu93gNNy1RqcQDJbhwaY0NQmaz/Nw7g/tb5Eu1VLzW93GrfkvF/wAW+tLUn2bXxaff6aedEDhhS/4ve/pA9r/uH+Dy73gNVi1apd4AaNGg9PmbqkBCnGL4ydv1wXrxFKfJKl64+kNCEKZAFlYNwP2btHd08nbH9FjKJSkrVE4S3XZN7SCQdQhbynw92Lw769MZqlD/AIwGppnu1IHqD5eK0KhjyqdrmtGu/wDvkSy49ymuD1XrquYEJEJoVtFQkKagQotUAIQhACsifBOFKFKgIklJTSSCxFqITTCdBYoQmkE6CwQmEIoLEpJJSgCSFFNDAaSaikA0ws7A8IrVrsYcu73dln/lufASVnUhh8KZqAV6g0bo0Hm79z5KmeWK0Wr6L1oXRxSer0XVmRwrobiq9EYktFPDzes+wMa5Rq4+w5kC6hXxeFw3ZoMFapoXvuwX5DveQ7I3L9VicY6S4nFNFOpUPVN7tJtqbfJoWlVXZZMn+16dE/u/wvqyx5IQ/wBa16v8L8v5GTi8U+s7PUcXO0k7DYAaADkLBY6ApBalFLRGZu9WIJoQmISE0kwBCaSANz0S46/AYlldozAS2ozapSdZ7CN7X8wFs+n3AWYeo2vh74XEjrKJ+7muaZ8tvBckV6D9HWNpYtjuE4s/ZVpOHfvSr3NidAfx81z9q3sMv8iC4aSXWPXxjx8NDXhcZJ45c+Hczz9SWw4/werga78PWbD2H0cNnDwIWslboTU4qUeDMsouLpjQiU1MiKE1FNLdASaAhFDGopwhMAQmooAmlKimgBJpAJwkAJpQhADlNRhZNPCkiTYeNlFyUeI1FvRFNOmXGAJPILocHwuhhoqY50nUYZh7Z/6rh3R4a+W+oGN6sRT1+98wOfiVhveXGSZO5KonGeTS6Xm/4+5anCPe/L+zp+lfTOtji1rGijRptyU6bIGVg0EgBcsUpQArIY4wVRRGc3J2wTCIThTIAmkhSoQ0ISSAaEJoASEkJ0Aip0ahaQWkgggtIsQRoQVFQKQ0ey1ur6R8Oa/stx+GGUu0zcmu/tfsdneEryGrTLHFrgWuaSHA2IIMEEcwVuOiPHXYHENqa03diq3YsOpjmNR+q2/T/BA1etBkuAIcNKtOOy+d3gWPMAHmuVs+9su0PA9cctY93WPh65tm2WNZ8TyR+KPFfn7/AGXI4xCELrGEEIQmAIhCECBIoQgY0QhCQAiEIQAFAKaEARVtGiXeXNCFCcqVonCKk6ZeXtp6CTzKxqtZzzcoQkoq7G5aUQUZQhTIskEIQgGNCEJsQJyhCGIEkIQgBCEIAaSEIQAolCEMAauo4VjDXw5oOu6h26Z/t3bP72QhZNsinicua1Rq2OTWVJc9H4HP4mnlPgqUIWnG7imZ5qpNAhCFIif/2Q==";
                        break;
                    case 1:
                        imgBase64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgVFhUYGBgaGBgYGBgYGBgYGRkYGhgZGRgYGBgcIS4lHB4rIRkYJjgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHxISHjQrJCs0NDQ1NDQ0NDQ0NDQ0NjQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAKgBLAMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAADBAECBQAGB//EADwQAAEDAgQDBgQDBwMFAAAAAAEAAhEDIQQSMUEFUWETInGBkaEGMrHBQtHwFSNSYnKy4QcUgjOiwtLx/8QAGQEAAwEBAQAAAAAAAAAAAAAAAQIDAAQF/8QAJhEAAwABBAICAQUBAAAAAAAAAAECEQMSITFBUSJhEwQyQoGRFP/aAAwDAQACEQMRAD8A8axiuGJam4pyk8LkrKO2cMjKqPYmHuHNIVq8aFCcsFYQHEhKFHfVlCcF0Tx2c1cvgGpBXQpCcAelUIWhhsWd1kyrsrQVOpVDzTR6ai4OTbMKCvMUsaRommcWeN1zVo14OidafJ6EYUc1V+FIWCOLvmxWlhuIuOqlWlc8lJ1Jp4QR9FBOHK0BWB2XdoEipoq0hI4QwlKrXNWz23JL4hocNE0088i1Poxqr2uHeSr8LPykFaFbCIbKMLom8LghUZfKMx9IjUKkLZeGEd71SdXDt/CZVZ1M9ka02uhGF0Js4U7X6IL6ZBghMqT6EctAoUQrwoITZAUhQQrwuIWBgGuViFBCYxUqFZQVjEKFK6FjFCuVlUhYBELlK6FgGvRIKaFNZ2FqAapw1p0XNcvPB1zSxyEdTlJ1cMeSdoSnGtSbnI21UjJZhEUYKN1qCnKsMGCg9ZhWkjHfw/olH4N2wXqBhVxo9FlrtAeimeXbhHnQIeGwrnOcALjX1XrG0hsFk8FA7WtJA71r6950/ZOtZuW/Qj0UmkJHhrx+FDfRcNQV6+nSB0Mph2Aa4XA9FL/qx2h/wJ9M8KAnsK8rSx/CA2SB6LJpiCrq5ueCe1w+TYpVVdzlntcRujMr81Bx6OhansabUhHZVB1STXgqwSOR1Q09oS1Wl0R6b0yKg5Sly5G4Zg1qZSNamWr0GIw5cZAhJPwLzq1XnURCoz0ZLXuFwnKNZrwWusdj1R/9oRNlnVmZXRoqqlXRJy57KvZBgqhamH3vvF0MtVE8kmsAiFUhFLVUhEXAMhQQrkKpCJipCqiEKpCwCqqrQoTGIhQpUFYxUrlZVWAGa9XNQoQUkpcByMUMSWrXw/EGx3lggrpSVpquyk6jk9OziDDYJ2i6V46k+CtzAcQGhXPqaOF8S8au7s3s8BDL5VG1Wui8rn0iDI0XLjBck01jfD1AF9V+4MDwJcT9At+g6dQkvhmgIqH+YfQn7qk1iX/QlTmkamFoAEkRJ1PPxTjjCG2mdlV9Nx5rna3Mfo57Q4QQsPivCCO+wSOQXpsHhzF00+hbRGbcPgzncuT5sWkWKs1q9dxDgYf3m2Kxq3CXtOk+H5LsjXmkQek0ZoCKx5CO/BvGrT6IQYm3Jmw0FFUKTiIQixdkQ2yHcw9LHkLQocYaPmA9FjFiqWJa0ooKukegrcYoEfKT4BeN4/ic1U5LMgFo30vPWZ9k+WLJ4q2HN8PuqaOkprglrXTXIqKrv4j6p7DElsm6z1p4RvcHn9SumuEQns4tUEIxaqFqRMdoCQqkIxCoQmFwCIUFXIVSEQFCFBCuQqkLAwVVSrlVKYxWFylRCxiQpChSFjEqQFwVglMcApauAV2hYIfDYgtIMr0bMaCBfZebYxEpkjRQ1NOaLRbR6XCVxddwEDK8E/iH9oWIzEHe5TNOrlcYJm3houetJ4a9nTNJrJ7Jr40RKD7rJ4bjC5ve8JWiwjLYrhqXLwyieRitj2sIabcyrYjGsYJJ9LrzWPrF1iNLSgMFolVWllZYNx6XCcSY8losUpxAuadiFjMJaZFit/BjtmQRcbrOVLz4BltGazF7hpHgVZ1dr7PYPEC6KMCWuIOnNamHwDIkknyTVhcirL4PP1OHsd8joPIlKVcG9urT46j1XqqlCgPwlJuoMnuVS3o6YWnVYXJ5osVSxb9bCkXewEfxs/wvH/E5cx7WMecjmB0CxmSIPoujSrfWCep8VkpjeIhhyhpLhrNgPzWXiMS55BIAidJ3Qmt3XErumVJx1Trs7KnsPi2taGkG24ukZUSs1kyeDaY8OuDK5zVj03kGQYK1MPiQ4XIBGv5pGsDqsnFqoWozXA3BlVc1BMLQEhUIRXBVcE4gEhQQiEKhCICkKCFchQVgYBkKFcqExioUyoUhYxYKwVQrgJTIlqMxUCs0oMZDNMjQq4EIDSigpGiiYVgBI8Uep8xQaLbjxCYqtuo1+4tP7Q1HFOamaXEXgnr7JFrUZjUlTL8BVMMx5MyUWmqsplHYxTpodBW0wU/gHOYZGnJK0WrTw7J2ULfAyH2YsVAWugJxmGYwDvW23WczCGbLUocPMXFlGqwOvsz8dhp0WNXwrheF6HimKpYZmeq9rAZDQdXEAmGgXOi8PxT/AFAkZaFAC3zVTN+jGn3zeSto6d30uBLuJ7Y5icf2DC8uIA25nZoC8Fj8a6tUL3xJ2Fg0DQD9bq3EOJ1ax/eOm8hoAa0TyA+6Vpi69LR0VHL7OLV1dzwughCG4ojtEIq6JMPhX91/M5ZO+STmHrk9E1iOxNQdnmLMvezgTOXvGBoOSvw7h7CxtQve0lzwMgbbKBqSd5Kddwxjh8z9RIAptB8gNlGrlUdEaVOVhHngphMcQwwpvcwGQMpBPJzGu/8AKPJBCsmmsog5w8M0sDSLWkHWfsCjuaq4eoCW3BJZBE3Bbz9T6IzmqLfJRLgXc1CcEy8ITgmTM0AIVCjOCo4JhARUEK5UIgKEKsK5CqsAGrBS5iqsbBYK7CqBXCwQgV2hQxqKxiVsZLJzQitCJTZZSKaTJTaWoC48U+WSlqFPfqtJjLArnusM6Jn4gOyR8NRko5ZoE5h6AAJGqlV8BUlBTgLmUCmGCCJT7HsPJRdYGwIYelda1KnEJUMh20bJ+gNlnyFDFEw6+i1Dig220IOFwsiUd/DyWkjUDTml/HuA7Xk+T/EOGqYvEVapc0MY80mB2b5WzERMTObzXmcdQDHFtpGsEwRAIib7r3+JaWUsUIGZ1QFoJgmSGkjnESvBYum4uJdruT6L09Dd14XRx6u3x35EXaq7TdQ9sLnRBO8iPCDP2XSQLqhClrpUnmsEZwGKqt7jKjmMEuMaDQE+JsE2/GVTYVKrTtLzB6GAIWbg62R19xB33BB9QFs8S4jUeGF5GWmA1rWDLImdNiTqVCp+XSLab+PbMSq8ucS4kuOpJknxlcSqkSVJ9piYViJtUgzJ3HZnMLM0D/iY52zJlzErw/C5WOeHh2bLYC4g73sb6LRc1c1PDOiVwJuYhPamntQXtTJgaFnBUcEw5qE5qdMRoA5UKK4IZCYQqVVWIVETMgOUFDBVljF2ogQQrsesYbpI9NspJjkxRqkKdJlZx5HMsIzGSgsqSAiscApPJVYG2shsdQtChTsPBZzXzC0G1CI8Aua8nQugvZkHmnqTcol3kEtTdbMlsbjy1heY7oJb1doB6wpYdPCD1ywGM423tW0oMktFi2AXGADJ/UrewGHdHete0r5vUruc7O6C6+wi87ea918Lh9ZjXtce6S1zZJAI3vrb6q+tpKJTX9kIt1TTN5mF7yfwtLZCAeMrDuHX5wTy6JbG1GsOZxJymABYea50slc4PU4RrWNkla2ErBwtpseaxGw+kCLiNvqnaeCcOyyHuNaZG5nLB+vqunQyq4OXVw+wHHuCUnsc4NDXAEyLTAJM+6+I8apNa8gmBtAlfaviYvbThgdHezE53gAiNGySLmy+E8aqntHCQ7KS2RMW5SJXXPNNdEelky3hvM+iqND5fUfmrOJ5IbiqClWmCrhwPRDKsHDkmAgvZTeVxZCEHKc/RLgbKJc6FAqnKW7Ez5jdVlWfltlnS8x828dEwuQ+GxT2gtBABInS8eKeq4nEAZiCBzLQNp0KyqeonTMJ8JW4+g2o2tke9zQSWS9xmBIzA323Uqwnyik5a4Y4QYvruhPapoYhrgwTJLZtoctjfxBV3hR6ZftCjghvCYeEF4VETaF3hDcEdwQnJ0I0BchyiuQqlPTw+5TClCzW4sY+t/ZXfTLdSN7cotdDUlyYBwUqbRMmZFotEGTM6zFo3VUoQrXK4cgAq+ZbAUxunVsuZXMwkw5SwlLtQdzNzBPkgLayFsOMgECJ002XnOFu7/kfsm+IYo5yzYRHoCuS4zWEdk1icnoGVg6yzPiMkU2U26veB5AH7kLuFPEXGi1qbA8yRYaTEaa36KPEXn0M/lJ4BpsvoHwHWdQqmg+Iq0mV2R1Fx4x/avn7KZgaxpO08l924a2g1jQ6m0uYMrXZQHBszlDtYXT+otKcPyc2mn2hksBidVk46o3K9hZJbJNvm8CtV+V0xIP4Rb3QqOBkmdVwo6M+zP4NxB4DYaQNI1W/T4uO3eye6wN0Ghy5j9D6FCo4QhwknLyFrTO3VedrVctZ3fJa+o4hskxDXNjoMqtptquBbmay/SPobKgIkEEHRfBf9S8CKONeGue4VB2oziIL3ulrbAFoIt9SvRYfjNfDNextRjg0taWOJcWtIbBaTB3i/ovE/GHHnYusHvABYxrBHId7zu5y7ppt4aONypWTDeTKqE5gMKHvYwkgO1IidCd1q434fYxuZr3OMgAHLcuIAHujWrMtS+x40aqXS6POtYb2lGoWuWB3QzHsVsfsOlBl7iQS3umW5wCcpzMB0BgiQYN0GphsIMwz1ZBcBYai17IflmuFn/A/hqeXj/TLxEuNmBo5DTxuriq1r3ZWNIOgcM0D1QXtaCYmNp1UMEnkqY4JN8hH1CTOVg0sIAt0lDDD09R+aLiKIa7KHNeIa6QZF2gkeImD4FM4ZzDAdnzEgd11r20Q3YWUMp3VhvAjlKa4ZTD3ta4SDM3I/CTqFqjhNMwcxBc8MEkkufDSdBYd9t+ui7heBYRmJcHAubqNiQkeqmmWn9NW7HBHDsOBmFiWOe0HcC9v1zRXyARAv6+S1PhrhzKj6xfUDAJPe/FFoEDWETilKk0Sx4N4iCD46I7MrcxM4e30YGYDZc+tLYyjxAuorVQl31ChtBuDUWFx0k6iNg0Fzj6ApOpqf8qS93NCcCbp0hGyzmmJjl76Kcth+tyqPkmbDoJj3JUsfAiyLAhYBcVYjZcGrAIJ2XK7KZKKzDDn+vELZSCpbFwURqK7CxB8yD7KjmQtlMO1rsvkGyvDYU06rBq0z7Js4lhFmBpA1yi6m214KzMvyiMCzI6SRBGxTdTCh7i7tGjNtBOgjbwS1HFC2a+uwiOi5+JBMgeVlKk92SqxjGTd4bgmi/ag8+7vy1lblPCsIHftyj/K8bhXucbW8dEwajxIIIPiYUKjL5KLrgRZw4nECg0yw1S0O2i0nyafZfWaTAPxSvlzsQRBkTNnXnreERmPedHmfNPqS7xkSZ2+T6fQe7PJaY57Lcw5BXyXC8RqDSofCSL8gE/R47Xn/qkc7ztb8Oqi5wO4dI+pls7+YXmON8GqZmvpFpIJlr5AuIkEbrzbfi/EtvmJGhDgwqzvj2qQQS3wyN05Snn3gk4pcGR8SYZzAXPBzF1z5SfKQvEluYOMic7RG8EPv/2j1C9hxzjRrMLcreYzSQDES0zIN95XiHAgrs0XmSGqsMeovfRc18BwaYBkETBsY0tKNi+Lvq75RY5RzG86pL/c9zLG4ny0+qoxybam9zXJt7S2y3g3sJxmmGEPkvIdcNaGlxBGY5Rdx3cb6rJrCXOcNDLvUj81DabC1svh2c5hBsyJzTpM2hdUpy54bpAiTAhoG56BCZSbaGqnUpPwL1tx1UUiJvpf6Iz2iXSN+ceqo5jb9I91TJJzzkmuGBxyOzNixIibXsiMbDgbWcPYhBY0cvqdkUs7wm4zyY5EjVB+hpXk1cRxeW/uw9riGy62oGWQLwYtNiksDinMdEgA/wAWg6qj6rGghoNz3XXBjl6pzgNJ76jmtzOdkJIDWPloIzd1+uo0upKZSfBWtSnSeefoJhnvbLgT3pjaRsY91ftKhPzwesrTOEeAczyy0Q7DVG2NvmaICT7ITlz4d20urFp9CBBQ3+hcexcYKs8TLT45vySrsNU5NPgVtfs1+UQwu1ksqU3dNJCVqcOI1ZVH/Frv7HLLU9mc+hFuAqkSGNPmEGrh3tsWel/cJx1PLYPe3nmpuH2QWuzA/vWW/ihpPgITKmK5Es3Np9VGccnJ4YXMCWgSI1Op6QdFU4J38I9f8ptyA5Ym1liY/XVGDARMX8UP/cE6sA/psuNRoG88uXms8hWBhmFdtlv/ADNkoxY/LAEAa9eiQbWvY+5+6KcVJvrz08uSVqhpqUEdUMEHNpvp0S1RkaExtNkZzzNzFoHVROa1miORN+kIrgD5Asbe60KWFGpdA6jXzVKZYLfMb+fI3hCYx7jYi/8AMB7kwlpt/Q0pT4yaTKbTJzgg20hEZh9YI6DIT4wYsqYcOaBnLW2iAZnW5ynVc8Q2TqRuMwifqovOcZOhdZaOLmiZM9ALbc/slnVkuCDNj9FDn7X9VRQSq8hs8XIOto/NFpSlWvhQ1j9STHO8IuQKjUZG594Caw9M5g46bAn3MXWG3MdHW/q9kZlAuJzPjmSQT5AlTqPsrN/RqYiq0GxHMwZOusfrZZFepmeY8Sb/AK3TreHMee4X9S4tA8ZA+6r+zm3MhjBq4nU8g46np7rS5Xk1qn4FXUxHzKmHqMY8Ocxjxu1wB9CQYKd7KiTGf0Ij1cQs/GBoeQwy3Yki/oSqS88EanCyW4zjWVnNyUxTy2yg2jcwLA+ASHZwmKeUzmyjrll3qnKWBY6M5gxo1rr7269E7pSsCKHXKMrKIMzqpe9xEchYek/RMYnChp7rswnQgh/pzVaGGDj8wIBM3gwN8puBomysZE21nAJ7De23uqOOs8h6haFJlPMBc/xCXCOUESPVWfgWl2Vof5iQZsADN7pd6XY+xtZQhTZb3+tlUkg67ynqmCEADOHXzTIEdBHvKXr4FwuJgm0kfVFUmBzSXQXDY0sY9gaDnBZAn8VhA3N7J7hXDcYx7KtPD1bXByOuCLjwIKz8BxF9B4exrc7ZyvsSCREg6aLZPxZVeIfXrC9xncBG+hJJ05JK3LpdhnD7Z6TAvxzzfDOa3cvdkjqAbn0Wo/hFRwuAT4euoXg/2g8yW1XnnD3kz4EyjM4xiWEDtag3ADzp4bLnem31wW3Hq6nwmw602E9GNaZ/qCC74QIuHPZ/Q94jymFgDjWJPdOJeLdT5ktapZijq7E1D4PcttpeQcPwbFb4brNjLWeOjsj/AK3SNbgWIg9+k6NA5gbPidkpVqA37Ukzq506bRKC6q6b1HOuTGaI6W2RW4zRWpwCrN6LHE7MfEeoCo/gbwY7E+VVsf3Iz8aTEmNOccrcteq5+PdP4f15pt1A2I89UaAYnxvPpzVcs6fZcuXV4Ofydltor5GROaD4WULlmZF2PdM2POfzTDHRH/sHeQC5ckoeRltVh173MSWe/wBlXDvaHWaTE7n1zCPdcuU8cMqqeUFxdeROcg8iTHkJP0StSpI52vEn/wCLlyMysGunyKOeq9pC5cqogyM6LTdy16wfquXLMK7GMPVjV0A2NpPonsPBd3TaJmCco5kT91y5R1EX02M4muwwO0dlFzo4zp8oOnUpd7w/TO4c3EDwAAFguXKalJFHTbEHMbJzMItAvIPUaFKPAmxULl0Qc2oGwhh0SbiLbnZFrYh3yOe4QTaT9h91y5ZpbjZangnDuAIhxJJiWtuTsLm56RsqYrK4kODg8H5nQCOhix9lC5D+Qf4gXVHADMBGgcGtnrO++6bw7mt7+eZaRIn30g8guXIvoEvDJdiGHm4nVwDmu8PmMjyCk0GlhPe2sQ7z3+q5clrjGCk/LOQDqAy2aZ1JIHPQTohGiDJ6amBfwB+gUrkZpiVKADDnaZ8CI8yitxVQRLs0WAd3gFy5Oueyb46Lsx/dLXMsdS38uSYoVWH8YHQgNPoRlPquXIVKGmmzqrGjS5gX587XuqNbex8zp6rlyVdDPspVdpv4X9Oip2v6lcuTIRn/2Q==";
                        break;
                    case 2:
                        imgBase64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUTEhIVFRUVFhUXGBUVFRUVFxUVFhUWFxUVFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGhAQGi0dHR8tLS0tLS0tLS0tLS0rLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSstN//AABEIAKgBLAMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAACAQMEBQYABwj/xAA7EAABAwEFBAcHAwQCAwAAAAABAAIRAwQFEiExBkFRYRMicYGRobEUFTJCUsHwYtHhByNy8ZKiNEPy/8QAGAEBAAMBAAAAAAAAAAAAAAAAAAECAwT/xAAgEQEBAAIDAQACAwAAAAAAAAAAAQIRAyExEiJBEzJh/9oADAMBAAIRAxEAPwD2MJCjQlAJQkI3BCUDL0w4KS5R3aqKGSE09PFNPVRFqKLWUyqotcIK6pqmY1T1RNtGRVRn7c3NRWtzU68FDYZULYnw5HCWk1E5EUrAihA1ypb72jZS6tMhz/8Aq3tPHkiF29waJJAHEqBXv6zs1qA/4yfRYG3XrVqnrvJ5aDwCgxOoPbmrfKdRtKu2LZypEjiXfaFJs+1NF+UOb2xHisJ0LsozB/MuKWjSJKt8oepULUCJBHHuT2KV59YbS6mIk5yOwx/KtrnvdzZY/MjTOSq3HQ1oSFVQvNx0CbdbqigXS7JUja9Qp91B5E4kFn0jRvUW12hvFRPYXH5ihF2nmgme2sjVD7yamm3ZyT3uw8EDFS8idGpt1rqHQK0oXUeCmNuzkgzFYVXGNE1Vul28ytkLCN4SixjggxfukcEXurktk6yN4JPZm8Amx6aQhIRoStQBQlGQhIQNuTDgpBCjuQMuTLwn3pp6oI7wolo0Ux6iWnQqBWVNENPQp2romQYBT9FU15UiM1UipCuvbwTgIQvsQdmAoT3FYLYeCaq24nQK2N1rNX9a2sPRUz1vmcPlHLnzUoQb6vd2Eta6NxIPkFlXvn89BvUu8HS7CNAP9JuhYXPOWatJIt/kRzI/+W+qKhaXN07wVp7BsxUeNNVLtOwlWAW96feKf48mVsVcSQR1SCYO4jh6p+pahq3XeDv/AJ5o7TcVWm7NpyUOpY3DVPqIuNiRWtQe2QId69ycFpAw5ajUag79FWzGXA6oXO3KVWzua1sc4NcYneYz/la+z3Uw8wvLbHVy4hejbJX30gwVDLxv+obj+/YFXKCyZdbAnxYGqaQhKoI3sjQnW0GgaJS2E6DkgBtEcEQphE1GEDWFGQuKR5QCWoYSlyQlAhCAhEHJp780HpCQpUhWwFyAoykIQNFMuCecmXIGXhNPCdqBNPVaGHqJaBkpjlErqtFfaGGMlXVH6q1qVS0xEoGtxfIoGco0AHyVaMqAKZUu8kzACg3w0UKTqjtGjz0HmQFOjtQbVbQ9G3o6ebzPd+SsJTcc3EyTJJ4lP25xc6XfE458hrH5xQlsU3Hl5CFaReKu0Ol2XzGO4CFutl7mloJCxl30sVQfmua9g2fskNCx5sv024cf3U+wXeBoFbss3JO2aiptOmsZivclRa7kp1PiaJ471Q3jsVTeCBkexboMTVQLTWlfrbwfaLZR9AkgSOKyjpbqPJfQV+Xe2o0yF45tXdRpuKvhnu6queHW4prPaxPDw/hXN3WsseHsMEcNCPuFnKbOX4FY2N8dWeYPNbsHqllvUvaDGoTvtrjuVPsbUbUBYdRmBy+aByyPetnSsLCBks7EKN9qqJW2ipCvfYmcErbE3goFCLRU3IjWq8Qr72RnBcbIzgiNKE1anFNvqP3uV++xsQGws4IaUBc/6kDi/iVo2WVg3I/ZWRoENMsS/iUw4VP1LYtszeARdA3gPBDTYpClXLVIXBAUZQlA28Jh6fqKO9A1UTRTjymtyrQ09RqqlPCiVlWgaLdU6GoLOFIDJUhkrEbd3gTUZRGjeue2P7Y55k5di3bmxqvKtrah9rrOnm3kQ0MHmJRMZUvxVPzv+ycr1B0ZHHEP+o/hQG1esSN37wPRJiLhHMDyj7Kdrp+zlB7ntDGguMZunCN0mPRehU7NeFMSy00nfowtb3CRHoslZbHVo08bAZIy5c1PZclQ2Z9pda3GqC2KTTGUxLgczruWV/KtfI2lz7WvB6O00iwjeAQCOInI9xWzs9drhIMgryC561oYf7hNWgXFjahbHWAkiOzw8V6Ls9WLxA3KmV1dJmO5tocQQVGrP33aXDqtcW8xr3LIXlb34/8AzujP0lzh6FTMpekXGzturWF5h/UNokcVorJarwDMbalK0tGZbPXiNzoE96yO3VtbUDXtkcjkQdIPMFVk1lFt/jWTAADuyPt90tn0B4H+fztUR7+r2mPUKTd7pyO/98vPLvXU5Wg2at/RWhh3E4f+WX7L12yHwIkff1HivCG1C13MEGez/S9tuSvjo0n8WA9mn7+SrSrLClhE2IStCINwlLU5CRBHcF2FOOCSFQAWJQE6RkghSBASpCUqgatclKQLYIUBRuQFA29RqilVFEegZqHJNg5JypoU03RVoRyh1tVLcotRVoWzp+m+FHo704HBSOtFT88gvG9q7V/erH6og8MTGE+MBeqX7a8FIkRiywji6Rhb3nevC71tUF7XH5s5yyGTexExCY7zUm7WYqjW8S31CrsfPvV9sbZ+ktTDubJ/ZMuo0x7r2O6bvBpgOG5WNK52DTTuKG7zkFb0ohc0dGXSmvG7qeHMTzga9ykXFZQxhPGfJM3hULnho0nVWYpYaUDgo9peopbwu81ZOKPNZnaDZmz9Gx1Oi97gXdIcebuqcJkSAAZkYeC31gZIKOvYWu3QeIyWmG5OlMu+q8Zug17HaGMa4ua8AuDcw0nUHmIE9qHbqjAL9znAntgSV6zVuimMyATxK89/qZSaKJj6go3vKHXy8za2Wnt9Z+4SWN8GDofz87F1AbuUd8yuNPNdTnS6rt++c/NevbCVi6yNB3Fw85H5yXjmKfEL1LYy2dHZwMJzk+Z/jwWdMm0DtE41ypG3qfoKP3m7cxFNrslISqT3pU+nzQm86nAeKjs2uyUIVGbxqcknt9TiE0bi+c5CXKhdbKn1BNOtVQ/P5Jo2vnPS41nRVqfWfBdjqfU7wTRt6kUiWEi1SFCAjKAlA29RKqmPUKqgZfoU2NE5uTTVWjnKMU+4qO4KtAWpktyMFVzLM/e/zVkLJOclEbK2IhSMlft2urFjG1Dk4SeZIiPErVWK47Mwhwo0x0QgOwNLsThn1omc++VCYwNrtAENY3Ee0zHoVeWAF0cBn2uOvgssr21wnTNbRf04slqxVMPQV3aPp/DImMdOcLtMzkTxWQ2e2aqWKs6nWAxyYcM2vZuc0/kLc/1CvqvZadJ9FgdNZrCDMZtdGY0zETzCW31MdGhUfBeSM9PiaSQOUeirlbrTbDHvY7C6FPfUJGSr7Kqi+78q0apb0b8MAh7Wl88QAJM9yzlazHd0kWmzWoPa6m6WgnE0iQ5p0je1w46clYVb4rYWhtCo/jGAAcyXOCq7BtLB6wMZTIwxPd6q9st8UniJy7ip1pbLDL3W0+66stBiATp+d6l1aiih43ack1XrQrzLUYa3QW2tAzXk+39sL4YOOI9n4VvL1tciFg7/ALJ1H1KgIxzBiMQbuadOZ7kw9TlOtRhaAznkT5wjra+PqhLYaOz1z/bxSVdBxM+AK6XNB2cSQN5IXtFx3ThoUxHyz/yJcPVeU7O2Lpa9GnvdVaDugAyfKfBe+U2gAADLd2blVGSsZdxjRE66SVahGEVU3ulOtukK0hKEFULqCT3S1WrkMIKv3SJTguxqsEoCjQge7m7knsDVPcm1FGlKFKhK1HFDCIoUDbioNcqa05eWeuWX2UG0oGQUIXNSA5KtAFNOKdKZeFWiQw5LnDL7oGGAs/tVtI2hTLWZ1CNcuqNC7Pfn/vRSD9qDqlTDoC1k/qgkjww+Kubntw+A5EZdp4968p2Rv0mpVouIDahxsB1xNgQDvOEA8citlQtJkGc9xXNnbMnVhjvFurTZKVZmGoxr2nc4A5gyDyIOcrM7T3VXZRY2zs6RtN7TE9cNaCMgfjyPb2qbdt67ir+nUDgrzWURLlhWLuivibz3g6gjUEblPtNmFQZj85KffNg/9rR1h8cfM3jzI9J5JuxvBhZfOuq1+t/lFObJh6rmCo3jvHao9e5A8yxj6RPzB5H/AFzb5LYsY0pqtSA0V9XS389U1zWB9Bpa+qakmRIjCOHNSbS8Ja1UDesttLtLTs7C5xz3NGrjuAUSb8Ut/dUO3u0hoYadKDUd1iDmAwHf26ePBYi8r/tFqc1tR0UwS4UwThBMYjnz+6jWm1OrPfWqmXOPgNwHIaJbDR1cfzX87l044TGOa5XINoaSY5j8/OCGv8Y4Ny8v4U+nZCetGmfl/Crn5vgfNBHMqUVq/wCndMG20iRvqO78JH7r2dogBeR7INFK3tZM4Kj2zyLnUz2DNp8V642oJ1zUK0cI0K4lEDaEoahDoRY0COCFc56AFBxRNQwiaUCkIMCNJiQX65cV0q4GEkpZSIGnDJQLWrBwUC16ZIIjClKapHPnxTpVA25RqrjGalOVNflqw08LZxuIAiJEkAnPTKe9RRHve/qLGkGsGwMyTofpa0dZzuxedbQ7R0HMcKQxOcT8WbWAtALswMdXnoN3EptffoMUaWEMbJODMF5yJLjm90bzvJWLc6dFMi0giZcOAgz2LS3Jtc+kQ2tL2H5tXt7fqHn26LNnqjmU9dFjNaq1vef8RqcvzNRljL6vLcfHsF23gyoA+m4OB0IPl2rXXLap3r50u+96lnrF9J2UmW54XgHIEbstDqPJe0bFXq20APZo4Zg6gjUHmFhcLhWsymcegtzCw20dd1iqAtGKk/dvYeA/TyW5oaKi21sYqWepIzDcQ7WkH0Vs5ubV48tXSis+1dMjUjkQkte1jY6oJPYs9Y7CCrR1jaBosdt9RTW+/K9QnD1R6BYbaAOqVQCZjUkrd3mAxhI1K8+tdSXk7vVa8VZ8k6CKE5D4W6niVLsbBr4Ds+38qG60F3VGQ07VID8LZ03Ds0ldG2BbdeBktBhs7t5hwHq7wVTUPdhOvLcft4ILY7OBpl47vzmlpZz4/nJSql0rZUBDw4SHF0nMkmJmewLY3Lfl49G0sqgNJIbipNOIiTExpkfBZCpYnMaDOvpmVvNhLwa7oaVYAYC7C7KJLXdV28OOLI6HMa5LLPLU6aY4d9rrZjbipWcaNalNRoMlhDSYMOIYTGXAHmthQtLX6HuzBg744c9F5tsrY+mvKs9o6n90zw6zWt8SD4FbS0u6EgQSM9Nx4g7jy3qJn3pGWGu14TKJpVGy+f0u8Evvf9BVu2S4qFCxVJvf9BQ+9TuZ5qeza6L0nSBUvvJ30eaadeb/AKR4pqm4vzUSdIqH3nU4N8UJvGp+lRqo3HopQonJFqkhSJHrkAvVZbHZEdvkrNw/OSr7X90Fa05j0T4hQ8cOzyUsBUDVYZFecf1Bv8sPs1L4iBijUYvlEaTI8uK9CvG0Np03vd8LWucewAk+i8FtlV1V7qj5x1XOcd5AJyH5wChbGbVtducanju7k3k3fmrulc9Rwjo3AcgfVWN13AS7AKTsTvhOku4FJnL00+bplaNkfUOTSeQE+PBPUbJVBORaRlwI5L0+hsw9gBZTcHiCZdw3QGlRb7ueo5vTYQCBD2tB0G8nl2aditlLIrNbeeMsAC9C/pI/BVqNOhDSO3MH0HgqJl3ytHsVZ8FZx5D1XPlnuN5hp7FROSrdpGzQq/4O9FNsTuqEF50cdN7fqa4eIKve8WU6yedWSmpbhlmoNB8aEo61cRquaOpndrLVDYBlYG01M4Wn2mr4j3/usrEuXTxzphyen7O3L870tqrZeAjwRBu7go1oBJ81rGVRDmrC77NJ0z18N35xSMpBonf5/mSvLjs85xrkNeIMz3KM8tROGO6n2yy42tgRk0acSAfzsR26yupuDGjrP6oAmdRhIjgQTK0TLuHQBwGYIz54ssuEAJqyWU1LVDBNQkiT8giJPISSf8RxXLK6LGv2KugUbO2oR16zWPdyGGWt7pPeSp95UA4d6s6dIMY1jdGtDR2NEDyCg2/4T2Kb1Wc7QBc0aE/uj9zt4lWbTv8AzRK0rpcyvZdDEbbuZwU4uQkoInu6nwStu6n9IUkkrtEDXsFP6Qu9iZ9IUncmiUF+5IiISK4BzZy+64lESkKAXlV1uVgQoFtQUg+LvUpnqq9r5dOc8OEKwYqCl2woufZKrGmHPbhnhiIB7oKqbjuWlRYA1ucCXHU96vNoH9SOLmj1P2TVi0C5+W96dPD5sw+yzoEwaEHMK/bRQ1bICsm20qg59akH0yMQkPED4uPfr38lTMqOa+KmbDIcCN0a88/JWdyO6KrB+F/VPb8p+3erT3ewlxc0YsR1zEbl2YZXKSuXOTG2POb4uroKpaPgd1mHl9Pd6QpFw0oqeHqtdfd0irRLQOszrM7tW94y8Fm7lb1lz8uPzk248vrFu7AcgpNUZKJYdApj9Frj4xy9eWW6kadSo3g90dgJhVlpqEythflkHSvy1g+QWftlljcua+uzHuMLfwhUtnp/bx/IV9tI2Xd/3VdQozHOT+32XTx+MOT0yfMxlx4JnBmfM8O1Sa788v8AQiP471FrHcP9n9gtWISZ7PXt8Fp9jqgccJ3Z9x+8+qzr6WQA7+3VXGzjiyqHAZkHLuyKpnNxfD1vLxtcMbTYMT3GGtGWIg8tAJHLIrT7JXF7OwuccVV+b3duoHL9gqfZe7AX9I4GW73cTw4QDoOK3FJsLCRpnQvVdbzkVZVFWW7RRkjFIojIdg9EYC6kMh2D0RwumOWhLUIRrlIQBcAihcAgRMlPFDhQXhKRcuVwhQlcuQIVAtui5cgzbh1481PpLlyoK2/2zTn6XNPdp901dbpAXLlzcvrq4v6rqknnMXLlEShWhiuWWhzmte3e3rf5DIyFy5a8XtU5fIYfbSHCQAJzOem8qotVk6O0GNHdYd5z85XLk5O8UYdVoLFopjly5Tj4rl6zl90v7gPEeh/lZ692ZJFyxydPHeo892kMvaB+r+PRQLQcAnmB4GPt5rly24v6s+b1C58dE2RBB4DzMlcuWrEr3SeGpnvKv9ndaca4gM90mAuXKuXi2Hr2a56AawD13nfKtGLlywi+XrqirbaMly5VyMUqk7Idg9FxekXLpjnpS5diXLlKHY0LnrlygB0iF1ZcuUbH/9k=";
                        break;
                    case 3:
                        imgBase64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUSEhIVFRISFRUVFRAVFRUVFRUVFRUWFhUVFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OFxAQFSsdFx0tLS0tLS0tLS0tLS0tLS8tLS0tLSsrLS0tLS0tLy0tLS0tLS0rLS0uNzctLS0tLTguLf/AABEIAKgBLAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAAAwIEBQEGBwj/xAA9EAACAQIDBQYDBQcDBQAAAAAAAQIDEQQSIQUxUWGRExRBcYGhBhWxIjJSwfBCYnKCktHhIzNzByREorL/xAAYAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/EAB8RAQEBAAMAAgMBAAAAAAAAAAABEQISIQMTMUFRBP/aAAwDAQACEQMRAD8A+GgM7FnewYCgG9gw7BgKAb3dh3dgKAd3eXIO7S5AwkB/dZciSwUuXUGKwFruM+XU6tnz5dQYqAXPls+XU78sqcuoXKpAXfldTl1O/KqnLqDKogXvlVTl1OrZNTl1BlUAND5PU5dTq2NV5dRplZwGl8kq/u9Q+S1f3eo0ys0DR+S1f3eofJqvLqDKzgND5PU5dQ+UVOXUGVngX/lFTl1OfKqnLqDKogXvlVTl1OPZlTl1BlUgLny6fLqc+Xz5dQYqAWngJ8uodxny6hMVQLPcZ8uodxny6gVgLPcZcupx4SXIB6iCJ2A21iJJROpHURXLHbHUiSQMRSJKJKxJQIuIqJOCJpXOqIMSiNhTIRiWIozRzIdjEnEnlIsiKgSVMnFD4xI0R2ROFEswgOhSArRoEo0C/CiOhQJpjOVAjKga/d+RCWHGrjK7AhKia88OJnQGpjLlRIuiaMqQmUC6KPZEXTLkoinECq4kJUyzKJGxWVRwIuBZnAg4F0xWykZRLMokHEqYRlI5R+Ug0DCsouoiw4iai1BhNajKH2ZRcXZaPgQNr4p/3Yf8cfzGfDtCM4V8yvaP5SNOc5eawkdSGKP2b81r5kQ3BYZCD0tvukvN7i49mvsqVXMv9WTjbhZtX9hKhlla+qnHXyZmkqOIouE5Rl96Lafn4j6eDbV0a21MJSdbHvJUTp2dFWk1F9rBSVW17LI5ay8bCdnfcV+a+n9iWtRndlKLJKfFexqYnCNu6k1p6eHgcoYNv72VrW0o6O64mdVSpUr6x15ePQJRsalPZqcZNN3jTnNK2/Jlb18NJF3BbInVoxqJZ0782rNrz8PAmrJrAihkS/itlTg/utfuu9/RMqxpMaYlTQ+ECMKZYpoN9LHYQLlGkFGncv0KBDEKWHLdPCl3C4a5q4fZ/IlrU4sTufIi8Ietjsp23C6uzLLcTsvV4+rhirUonqcRgTMr4axdYsYFSkVqkDXrUyjVplYZ04CpQL06YicSoqSgRyliUSDiUV5xFWLNhU0UIkhckOkiDKhLRCSGsgyogxFWOpYFVVr6E0O21joVpxlBSSjCMXmte6vwe4ufDWNp041lUllzxtHRu7tLhu3owonUbY6+YZBrI143WnUiCR2xK09BKP8A2mG/5WveRl4lWqP+NFWKJweq/iX1Jak4vYYnExVbaycknUpLLdpZn21J2XF2MrAUW6Slzbty+0vyK/xJBrF1lbXPu52R7H4S+GqtfCwlFJqTl4paNJp8fFmLW5xedjB9VSV/NSG4CLSir6fYeq/G5X/+Ue2pfA1TLdqSSlSWq10bhp/Vf0IYH4OrNwSi21GjJ6borPF353mnYzreMPZFPOql1/49V5Vpe9Jtq/8AKj0HwtQiqLjayU52W+yVSStfxG7K+G6tOU1KFrYerT/neHqfmb/wXsiU6CqONs7m7P8AelmVvRmeU88Xjcvqjsqkq1WpT7OX+lUyZZ6xleLeaCa3P8zNfw1Tq069RRbnCcFFQio3zRgslpStv8j6ZDZtpxdtEvezKmyNjOEJxf7cqUl/LGN/ozn15fxr7OL5dU2dhaVOSnKfauEJ01lsnm35r7jz1lc9D8dYGrSxGWotMkezen3ErJacGpczAoxOklez5v8ATPk4TjJ+FnDwNfBrjqUcPTXPobmApbtH0LrzdK1dnYRS3HrcBs1WV0ZWxaKvufQ9hh42RiTtcZ+Tl1hEMCrCsRgE1uNEDpfijzz5eW/l47amAUTzWMwrPo+OoK248jtShqznLlx6Je0147EULGdXgegxdIyq9M2xYyKsSvOJo1aZVqQNMKM0Kki5OAiUCitJCZotzQicQKskQY6SISiVCZIgxskQaKFyK9QtNCKiVyCjGR2MhK8ybOlZTciSkJzErkxTlIfh6lpRstVKLS5qSf5FNMYpdSWDd+K9rxxONrYmCajUnminZNJJJXt5Hq9kfE+Fp4WnS+1GrClSTlldu0i1m1XK584iNzN6mbx1rjyx9qofHeF7NxztOVpKV6iyyy6KzT3O3Q0cF8fULT/1ft6WeZONk4pLXW/3j4PGo+I+nXlxaMfXjXbX2+h8bRnJXlHLbEyvdOyhTqZb24/ZXQ2/+n22oTwdNSlCLi5Rtmino99mz4JRryUXZ+Fn/C2m11S6FultGrFJQm1FLdzSWZ9WPZ+GblfpeONpt2VSH9Uf7lHZW2Y1c6zQvTyJtSW+Sd/oz8/U9r17/wC7Li92uo/B7QqKDy1HHVt2ersuXmrFt5JOEex/6p43PiILTSlHc09XOd1deh4+hIryqyk7yk5P8Tbf1HU+RG41MLI3MBM8/hmlvNbCVuArrK91sWpa13ZHrMPUTWh852dXtY9bs7aCtvMS9bqfJx7RvAVo4tEamMSOn2R5vr5fwY2Wh5Tact+rNfH4085jK1zlPbr0cZ1mMjGX4mTXuamJkZ1Y2lZ8k2Qw2VVIOesFKLkuKT1RcqxSVzOqRbvyKzinNiZIsSidlh7LUqYoTZXmWq0RM0VFaQuQ2cRTKFsW0MmQbKiNhNWKuOYmtTd9wGTY6csdSOjLrOpHLEkgrqJojE7FEomTQtIZFEInEbBCoIdCT4iqtwu76PXeTUX5eoiM2xnMwHRS49EWIzXh7/2KsWOjEjUWqdQsUpiFQsotSjJu9463ja2+6tryvuLVBcrdCNRdoI0qE7Edg4PtZ5E4p2b+00lpv9S5i6Kg2tLq633XmrMzqyrOGr2NbDY21lxdjztGX7yXQuRrPNFOW533JW9iV0j1lLHSXg/VXv7Eam2F+3Feauvz/IyZYibSUYzd/BePTeZ2Lw1WLtNKnzqTjD2er9ETjKc8ephjIysoSjd7lUUJRb4Z7aPzS8zPxe1acG41sPG8W02nKLut+7T2PNfMKdJ3jetNaq6caV+NvvTX9JUxO05TcpzalObcpXWl5bzTn49HUxOCqbp1KTf4l2keqs10Zl7SwLpx7S6qUm7KrTeeKfCW5xfmkecnWu0opuT3Jat+SQ35i6Eakc151YOnKkneKT8ZvddeCWqfDxrJ2IxkX42Xhm0uLU09ItS8jBniLrUryrW3Fw16aKSvdXMzH15OyvpmW7zE4baUrWuvVJk6+MU1BNKLU020tLcf8ENSdO7sFTDbv16F2rUhb7L3+MUVK1LRavzerY1cKr4VeEtP1vFVcOvBjJOytdfVsRUr6pCGEd0u9d11ryEVcO1d7+BYqzluT/wU+9zu1o1bR6Ld+vYsZsKlp4efAS2/1cHi2k009fHmI7bm1y0/M3GVFI6jkRkZG7WHEjqQyVrJp6u+nAlBr9IKg4sEh+dE4zj4DVIiOpxJprggv5EpE424jVFMr5eRKMCKsQjzHKlfxK0KaHwtxRmlPhRt4j6dP9XKtNXdo3k+CTZap4eS32jbfmkotfyvX2I1xPpJ3LtJJauRnXjb793wjF/V2CNRcOpHTGzRrLfZ28LD4Y6S3R0/FL+7sZlPaDUbKy8lb3KrqNve2zfPjwyZfWPXoFjr/fqWXCEcz92l7lnDbUpQelJ1H+KrN288kLe8mecpK/jbzNjCbPbtLVJ/tVMtOHo5tJ+hza17Cp8V4irTUKUVTsrZoLL6Xe485jaLvnqSbbeu9385M9d8L0cGtatanKS3RjfKvWyuQ+NNt4fIo0I03JftuEXZck1b1sT39r5+o8PkcvtQg8v421GC85y0v6lOtVpx3yc3+GGkfWcl9E/MRj8XKcrzlKT4ybduSvuM+pM1jGrlfHSs1C0IvRxhdX/ik/tS8m7cijKRDtbC5yKjs5CXI6yEipUk+ZDM0RYZ7BnTaWMa0e70+pN4tvc15FKVReKRHtEtyt6jGtaHbyt+z1a+guVd8Ypvxu/a5WeL8LPqKnVT1a9d4xdPqVrJ6pt+L/IqyrMjOa9SDnwXqWJriqHXKLtp4EJT9BE56lZtRiTSOJolmNsxJI6kRzBcKZlR2wq4KRKH5kdUhKZLMTFOTfkSUuYhMnEuCwppcX62GQrW3JdL/UqpjoRb3JvkiWKvQrye+Ta4X06HWKo03+04x85a/wBKvL2LkeyVvtSnxUUoL0lK7/8AVGK3xKQ6N/AbPGpfcpU4c2nUl1m2uiRVnUb3v0/wGrZizFcWl7/QZGtFeDfnaP8Af6lFyByGI0FtCS+7aHOKs/6n9r3FxrNyu3dve3q35spORKnMmM62qONa8SFfGX8TM7UhOqMXVipWETqCnUIOZWXZsIy8BbYNhNSlIW2STuRaKuhsVOQVJinIuI42cuDOGkckz0HwdhIt18RKUbYSjUmqcknnlKlVUbX3WaT3PWx5+4RqNXt43Xo1ZmbFlyt3bNfZrUO70cRGcYRU7zj2U5ZUnbMs618bK/AxcZXUpNqKitPsq78N93qKSuImhOOFuiTFSZJkGbjIuCbIo6VNSudiQJRIqR1M4kSAkiSRHMdTCmxRJNc/oJTO3IHKpwS+p3tW97eoiLJpkNPhIswmUoMZGYrUq/GVzpUjVJrEGcXVhM42IjUJZiJpkmRzC2wTKadmONkFI5KQR25y5C4XGDrZ25C5F1bBDcxCpMS6jOZiyK5KRBsk2KkympqYSkLuccisp3ISkcbOMQTzoWwZFhQQkSbItlggjpV7V8Q7Vk1jVq525U7Vh2z4jV1czHSl2zDtmTTV65JSKHbyDvEuJdNaFzqZnd4l+kd7xLiTTWlclGRl95lx9g71Lj7DTWtmO5jJ73Lj7B3ufH2QNa+cM5kd7nx9kHe5cfZBezaVQmqph98nx9kHfZ8fZEO0bfbEo1kYXfJ8fZB3yfH2QTY3u1Rx1TC77Pj7IO+T4+xMXtG06yDtjE73Lj7IO9z4+yKmtd1CEpGX3uXH2Qd6lx9gvZqZzmcy+9S4+wd6lx9i6mtTMRkzN7zLj7B3mXH2Q01fcjlyj3iXH2BYiXH2Gmr2YGUHiJHe8y4+w01cbOXKbxEuIduxpq2Rkyt28uJF1GNNQAAIyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//Z";
                        break;
                    default:
                        imgBase64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUTEhMWFRUXGBgaGBgYGBoYFxgYFx0XFxcaFxYbHSghGBolHxcYITEhJSkrLi4uGB8zODMsNygtLisBCgoKDg0OGBAQGi0fHyUtLS0tLS0vLS0tLS0tLS0tLS0tKy0tLS0rLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAEAAECAwUGBwj/xABDEAABAgQEAwYDBgQEBAcAAAABAhEAAyExBAUSQSJRYQYTcYGRoTLB8BQjQrHR4VJigvEVQ3KSJDNTogcWF2OjsuL/xAAZAQADAQEBAAAAAAAAAAAAAAAAAQIDBAX/xAApEQACAgMAAQMCBgMAAAAAAAAAAQIRAxIhMQQUQVGBBRNC0eHwMmFx/9oADAMBAAIRAxEAPwDxQzzzisrhmhaYAGhRaiXEiiHQFDwmi3u4slyYKFaKAmJd0Y1ZGCKhQWb3gqVgk6XJY8mobXPSHqxbIwxIMMZJjcAHKvhtE14RLlk6gAXazCmpxtYvaLWNkPIjCRJjSw+FAaos97foYUnCnXSt+Vb7Wb5QUMMxKUqBISTSzJd670r7RccRLyF8qTLa4BAJNQQbNTb3q0Wrw4UlRdPAAGcJP4hWnEoNU3jNXOfi4n/ESdTkueXD73PhGtg8e0taCEMvSXUApTpqwNw+9IvQjYoQhJBIKA5AcmxFebsRqehsBvFK8QC4SS1GJDFXMUJars/IPGjhpqKUe5BIS+prOfIt+tZ91LIF6s5IF6tYuzH9rQnjY1MxlJQVEh9Llg6QrfSCWIFLkC58ILww7tIUpKtK3KOoBKSb7MRXrB/coOkKJKQ7MHvUhvHrAszDovqYkE0BJerA+POsJ43Q1NC7xMxOoJUNLcTnhSdVCWZz8jSMuegFilT6fg6MaEDb02ETmkhJSLGpoL9GtEAdIYI3CnV8RCdQIFqEvaxF4xcaNU7I5rizMUFFSjpSlCdTOEofTZIDdDV9zA4TZLAORxEl2UGYkFtNCbPeCVod1GxUGVdNXID/AIVMOdA7xCStOo94kqASoABQBK66Sol3a3M06QDLsLJGospylV7oUduIWcvdqbkw8pwpw77PVzyP8Tgsdi8U4Z2bUG4QQTpFCGclgKEl/wBYIwYlhYMyqQapSpjYsQpqAHTAAWtK0LWmYChQJcfwqIOkMmgdyPA7RFK3YHanl5D6eBpuKUpTqLqaqqVIfcX2rBEqim2BsfVi352gANAoG9fIPWJqB9WNPyhJmBnd1E7gAMRV/OxhtdrD163hUOyKlRFa2A6++0RUsqLCpPuYHVNf6+qwmUgiZNe58YbU16OKQKXLttDqUb/JokqgkTd3hCaOdIFKoS1E3MMKCxOHOHgBReFDsVGOMOpNCIc4c3an1vGygyu6U4IW4Zq7+4b3aL8skImDRNJSmhHj18o0lGmYqVmTg8OkpUCoAlmFfUbdPOJzMuKKqIY/Vt4LxmFACkS1lUsEOCzuCTw0tUlgbuYEVMVMWNS1LUSA5cnYANudmENITZZJwb0AdzQByQenN40MJgdTHSzaQTQD12Jgjs7mSZQVwalFtJdmYHfb6tGjKPeaUhIS7OfNwRWwEaUZ2BGQmwTvzpbp57xcvCDQ7BQ0lxXhJJSNN3NEqfesHZjhUS5mhKwocwzbUatf1gfOFCWooSApLU4nKQ5oSKFTC4pWkWkZtmKqSASacNeYLEBuo6xbgsUQoo1KSFfdzFAOoSyXUwJbYxOYhKlEpdCSKByoqbyDuR5ekQ+x9Nq+9SNrtGtGV9AO5USyNSnBIa5Ae4u/DURCaSVJ12OkOKqYChFnoW8ukaacKC4uR7AED5gQ8vAuNR8Ldah2vQHz8YWpSmZy0p1KSnUUuyVEMSgGjpYsWr/TRofuakiqRSjXOpmc1Dh3D0esHysE62RKJDtUsW/WNrLsOtIVrlBTumW6gpgGDBzw3FWEJ0i07OUWmooUsK1cEuTTkGYC9njQk4p/ifhSAlq1SAEuTsw23FGFI6vLezqFAOkB2BLkkN8bbVCqjpHQ4bs3ISgoCQdTVYPSzE2jWLiZybPNpAWsgCoJs/LmNqG8dDg+ytAVqDnnQDq/1aOmwGSS5agdILOw8a3F7xqT5ThmpsPreDJL4QoHmmI7PB3Ltelzfns8AY7L2AcDZqBKgEBrjm7nmQ8ej47DJDsxH5+V45jH4WrMa/m3vHJPp0wZxM/Cbk/E973/ABPSvjtAzVJIe9+ZDP6l46LG4RjxA02r1Njb9YypmHIPT1Ht5xizZAqpFASTxV9Pi35jzia0MWG3K1BQxcZY4Wu1aC9SfEM0MhAoDQbnap5jZhbpEjIS5Sn0gVewZz0Bg7Dy2CmRqSXAJBcNV6G7Fz4RTJcFKnNOVFByd/WCZFW06dk1bdudqm/VoAD8IgMoq+LYMaFjxOLKcCli5eHw+HQQrUdJanI8nhYSeRRPNVWqXYEHmKCnUwUgA0a4Ad2ALipPJiR5wwMaZLJ+uQtFXddPrmeUak6VpqWe7O9PJx6wKEPQPXzfpT6pCopMBKYkgDesWLBaKYlotCU0Mow55dYaEAqc/aFETDQwILALkBhdja9hzAcdY28DljyUqRRTK1PXUxJdn4WDWgMSUkX8quXvbba+8dLleVkSdXfy0pAsQaUYudW9fWOrK7ZyYzkMfi1anURqAAsNhpAIZths8AKUpRSVWZgWagrcCpGr8o0szwUxXEw4k6wyWKgSXNNh1ag8IEkYNSSVJV8LMbVqxAuWNfSISG2gmVi2W6zqIDGxFE6UhwWLcPoY05M1RHC5FS4GoAHVuHagsa3jHThFtq0OwbYsQGdqM5UKnfnB+RZRMxHeJRpBRLUpQJ00HiDqN/2jVOvJm1fgMl5ijXqTxMQzjS4arpFq9Y1p2I7+pSNfEaUd62FhR45iWoqPwhNX5MyW0gly5Ae940MIolLOyg9zTegjRJPpk21wILuFuQQdQetiXYG7mrc3gJOpmNAfWo67RqyAE3uzbGvjvElYXvNOgOSzAB70ZmvQRZBimYknzPmLxqYKQlSXKhRQoTtuWsNhAGNwSwokpI6MwHQcop1FJ89opRslyo6nD4ZI8OkEITQDqegrS/lGdgsSiXLSFqcqqAC+lqV5Rp4XGpAcEVBG1iGq8RLGy45UX4TE6ak+Ua8nGa6MaVb8jHPoQTRupI5fQgjKMToUQaPTiOkMP5jSKiqIk7OqlEMCSwFaX+usCKxSXAfhe+/nHOT8/UknSaA/m4sb77QTlKu9Dn6peImi4s1sepJDgMG9WasYa5idQfY/VoGzPN9RMtILJdz4Utyi3KgpSgVA6bv83MYuP1N0xZpgULU6XIO96+O+0czj8sINo9BlYYUaKsRgEKpGTRopHmpwZ+UNh8GslkCpflZq3pZ49BX2fHKMnH5WEgsKtQ1oXiGjRM43SbVuGux39Xbb946XvS536PRuUaE3Cq16bjycOW+Q+iYeVqG6lAoIoSSEgK1pACqJ0u45KJ2rJQNhSHYMz3Lsfq8bGDBWpKNVCWc2AJZ6+sAT0LoVOCQVcT8VdLi4FBp66K9bEzGDtuGILHrd6+dIpITNDNpQlzFICwpjcWsCGd+ovtGfiC3S1rgbPs7H+0TQlTpLMCkqBJSHDkONZANQR6wJMmh73vu3KvKsOhWQnARAIG5YOx59abjrEl6kkKTXkb19IonOCRY8qeFW3hUWmX4iQlPwqcmAzEyTQ2ex3p19ogTR33518YVDsiTChBQ6+0KCgssl4uYhlCh2NOodvWIHMzoIAoaE7FmPlYWa/WAU45wR0h8PxMkszvWwdgT7D0jTezHWjSw2ZaWUUpU1WIJBYWUARQ1P9MQlTyUkswp4FndqvQBVn5UpASCQ7FnDFi1LNBUvEESwFJSsOKKBcaQG0nYH8TXYOzh6TZDSLMNNWosC70ZIJo44ikVO5YV4RRjWSZ60Ek6kkEizGodm5UsbOIp0IABYkn4g7EEB3BZtJJHM0NqEkA8Gio4iSnZ7OQSeKpFgwAu9NF0zfBA0YA2Bqd6A0rY9dq3aNTBBhVncCgCgLKexq6R5ahuWpTJJDhDB2pVLgAqYklubdY2cOhWlOkkVCiBbUH4uQOzRrFGUmOmQVk2AUoWFzxWITQXoP5XjWyvBqSQRQi30/T3izLcG+kNXc1evifPaOly/Lt28OkVJNImLtlOHy0F6Eg/xMX5vzq8cr2h7IqMwmSmn8IsDu3TpHp+EwJMHJy2FjyKHkeTG5+Dw6V2bmCqg3SJJyickgj0j21eSoUC4fxgL/wAsy7qSCfP9Y6PcY2jnfp8iZ51koU5BRQbl4nm2C4nJd38tx5R2uNypKAwDRgZgmWlLFopJSVoltxdM8/myCk1JPLbk/lBOHzBWHoyg4BD0cGoPUGNLFYVClamFBRgat7ecD/4QFgudNAAxL3FncDzjOcTWEjOmZkWWgMQqutjqFKufEwLhsymSyxUdD1Y1Z6s+7Qdjsq00BcfM3oN6D0EBzcIkbMH3u3hzjB8N4s18vzkk8JUaBtQYmlRQ846DJxMUtzakcplc4SVh0uQagt57R3WS5vLmMkJ0k/nGM56riNoxv5OklYQERn4/J9W0aGDmkXjTkgKjC7Nqo87xeQl/hA8v2MYmKycs2m1XYC/W+8exYjCJaMTGYFJ2gGeXzcuIRu735A6qA7A8opVh1JG1RehI0k23TUflHoWIysVLeAann5bxlT8nowG/OARxE6TQcNQ7vu3uNwzxQZLDUE1flw02b8Tgh/Dd3jsMRlBrRyaeW3j+0ATcuIoQ2k1TWperh77bW8YHOkVGLZzc2QpQS5ejeSWAHpDDLy4JBCSbtSjP43jok4Amwdh7XPh/eCVYZ0poOEMze56m3kI536hI3WBnH/ZVUcO220VTpLdQa253+ukdn3Ao4pblFWKwoWAC3CGFhSpvzvGuPIpGc4OJw60VhR1aZLBg3+1J9yIUdGpjsea4dEbGElUtGbh5I3MbuXyQaOXjCJci5Y+6CCKhZKeL4QQARpbcgF3fh6xRKkDcUfnfo7Eg26c42sRJOmXpd0qB1MH/AAhidwGFDz6xZiMEhaiVEuSSS4DklyzRsmjFpmQJRKUpIJI+Eg0ALkhmu5u8HycOHOkXc2qL0flWvyi+Vg0pbQVAlwriulQYjzBIg+VhJabBWxJr50dmcxrEykU4TCClCWd7D62jcw+DA5GgZtnqR4ByKxRgFICgDUEjoQ+wcisEqxLFho8nPzjeFHPOzay6WBHVZcaR50M2UmxHp+8XI7UT0WX5aEn5RtKOypGUZavp63hwIvWoCPJZXb/FpsEK8UH5EQMO3uPSpR4Fatlpon/SygR+0c/tJs6PdwX1PZpKxCmkNHg57WZnr1/aD4DTp/2WgbC9vMfJcGctT/8AUTrr0KqjwtCfo5LtjXrIviR7LmbVjkMflwmEvHGf+oWJCnXN1fymWkD2Y+8aOD7XzJnEnSoVcBPq9XEdWNaqrOXI9ndGt/hoQIDmpAdoFnZytfxDyFPUQN3ZUQCoByKnb2te0TNlQQ+KXWtnuKtAasMqbX6YUHtB8rLlElyD151aNKThdArGTaNlZyZwkyWd6EMW877RbJxJQXciOvwgQ5CwD0IvDZzkMiYkmWyJgsLJV0Y2PWOfJxnRj6jNyDM5y5yQklVt6MOfRo73DY5P4Vg+Be148ZnYtclWniQrzB/tBuTdo+5VqI1dH58o5prbqOmPOM9mViHasNSPL867cT5Skd2lBQpIUHd6u4PgQY08X2tmDAGZMKJU5aVaNLq/qYgsW2LhyK1hKXCnjZ6CdHSA50pN44fsN2imzZakYiYVzQdSSQA8shI/CACxv4iOgn5mAL8/2hronFoInJTUUeMzEYQHaLsBhFK41kgGwg4LQFEBhffY0+bRzZX2kbY3XWYYwmmzg/TiK5iaNsLD843J0oG1Ix8QpSX2cc+dxHPrZ1QyJmPmGwALPcdHeITZaTpo1Kubl/JgzRLHTqEMOYNSzA2HneKVTKmj+oi4px8BJRk+ga8Oh6zW6Mo/kIaKcSniNr7F/eFHbGUqXTkeOFmJg8rHL1jUGVIppBFnetd25B3pDyZyXISdTULA0JDsaQ8/NpctTKVpeoBCrP4RPTIsxOWqUSaB6sAwrWg2ETRgiCCoEP8Aw7vS3XlavlA6u0EqnGBt8K6WqaflyNLRWrtDLIYqJ8jFpslxNiXhJSiVKWriewAqS9hQekH4fLpFNUxfXl7CORXncsPpC2Nizcn3+ngXEZ2VBtUxuT0/+3hGsZ0ZPG2d5/heFd9ayHtt0oU1EUqwODH+aoeJ/wDzHn4xxJ4QtSiWCU3JNgBHY5L2eEyWhc+auUpQUTLKKoIJCQSVh9QANBTV0jaOaKMpYJM05eGwYH/Mf+o/IQ5l4Mf5n/cqJSezWEcap0xt2cEf/GXijOsRhsJhytISqaTpQgrNf5qy06m3FKbxqvUwRk/STZVP+x/9X3P6RmHD4VROmYff9IzE5ti1hwZKR4I+bxFc3F7z5Yf/AEB2uzIi/eQXwyfYzfyv79jal4bDC8wecRUnC7FJ8BGIlE8h/tCGP8NX9BGfNRPmL0JUpQBvVIJ38REy9el+kqP4dJ/qOm7vDH4kpI61hSp+BlE6VoB3AL/9r3jKwvZ2ar/JKj1tv1Ji/Ej7KoJmJQksKcTMoUBZmN4xl61vxFI3h6BLjlZdN7SBdJEhZYVKqW30Jck9HERGYTlvrCZb7kK1+IQkhuTKVF2SvPn6KHSpQUFuQzsWr6RLESpKZmIK1hIQZmlJBAUQ4FRYPtHPLJOXlnVHBjh4RiKwRB1JnTQp31Ox9jT1jR+xYyek/ZZi9QCisqmqchKSss5oWHL0gKdmktkywEhQJ468QUxDmxAqxDXjcyHLMZMIEsqlhX4wpSEsQxN6uKMLxmatKjmcBjceJqQudMKauXCgwBNy7OzVizEZyvUalQe5UannHoa+wGhGozwtVRoQUpAcEAlZXUdAPWMYf+HKwarl+alEeyYqyVqvBTgc3w65SUYshi+harMwJBXsbVgXGdmHdUhb76SwB8FPy9YNxXYvDqSBPxUtGgkASgpStS9IAOupq1AN46Ts7k+HkICJswzdHCEgpQwHw6y4USzWYM17nCWN3cXRqskaqSs85xcmYpCUqSp5fDXYalHz+KDu1Ev/AIeVd0hLjoUpf3+qR6DjMPlmlSphmJArwTTcfhCQpTEnm2wvfzrMc3UhSjLUuWlWogayV6VU41ONTgAVIHSLSfyLZfBqdlcalaHCAlaKKVqJKnA22FD9CvSYNQKnUbR5/lePIqnwsK9HBpHRSMwbmOfQ1ofeE4v4C1R2v2wCAfto71+h5RgHNHeBxjnVq2aI/LM7OqTmQUsgGgFfFyPlGDn+ZKUrSn4UkamFR4b2O0ZJzRQJ0t+zq/aB5+M4j8z679INBphZmAlwp6EVfmLB4ZCww4mpufP68ozUqBq35fX9ovCRDUDRzomoOXr6woj3rUhRtwx2Z0Ga55lUuXhdeB16pGpHCjhBXMDK4w9jzgmVjsuMvDKl4bQFS5xICEj/ADEAOxrY+8eVqymZZj0Zf7w87CYhCUnvFgJDBlnhBLkN4naJ/MRejPbMjzDLynEvKfu5IUt0H4FKCadT0jKl5hgC3AkcyoKEeZysxxMmWFSZpBnS9M12X3gStRDuC3wpt16xSM+xiaEJUeqa+gaHsiaZ7jmKcqmZfh+/MkSjMWpJKigd4DpLKcF9J9hGUMnyJadKFYchyaTzyOmut7x5VmfaydPwsjCrlJSmSqYp0O6jMYhxs1fFxyjHGIoToUwvT84doD6Hyjshlhw88ypcpSiCATMKwCUBiXUbKUr06Ry8nsXhNRBwgYamPeTDYK0/j6J9Y4Psn2qkYWTiUrSrVNSyQBvpWjiL2GoHyMYMvHIFlEeDi3hAI9UndjcK4/4M1uy5tKsPx8opmdjMEjFYYCSoFaAsp1qLMNW5NiFjyHn55LzlY+HELHhMUPnGhKz8ksqcsqElSQorUVayVtpU7j4nhgeyr7NYTWB3f49PxL3JpfkIGndlcFNlkqlPcg6l0LT/AOb/ANtPpHjyM8xYtisR0++mUPTipBkvtdj0hhi5rcirV0/EDzPqYKGep4TsdgRNl6cOnhUhjqW//MkCvF/DMVHD5hNm4XF4gyUyyk4mexmLYBpqmSkOCRA2Sds8wOIlA4lSgVpcGXKL1H8j7D0ENiJpmrda6lalHUn8S1FSjQipJ5REyohSO1OPJ0thkAb6Vqp0ZbG0ZXaLD4mYmdOmzEEMjUEpIHBRATxFnJLmCsTIGjQVIIJcFlagbOCPCK8X3gwq5YZfeTJKU6ak1JNGcEtbqYQf8NDs3lc2RP70uUl9Q4Hc1F5lLdY4nOMaqZOnFyAqYo6fPf0j0UYnEaEvhZrgkqIQtiCGSBQ0FT/ePNcTgp4JUuTNTUklUtSb13FItgrvpr9nMpTiT94tKQBpcuSyQEpYBQrS8dnluS6JgRhp6FLCCaiwDuSTMbp53jy2Wgqqmsa2VTsRL7woCw8spID8WogaSxqCCXHSBCas6/G5q+tEyfJ1JJSWlhQCg/8ANUUvUdYhOmoSK4mWPCXL9gXjg1Spi1HhUVE1DF/SKqih9D+kOxancYRap08S0YrgSgrUe6k0IOkBPBcgn6MbWCnIlTFrXilz06QAhWhg5DqZKQzWDDeOAykLQvUEqSFJId2DGvixZvOCcTmCQDpI1BqEHzHjCbHqd9meMlzkIlIoDxKA5C3qT7R5di8T3i1qVupxy5AeSaR1HZjMJa5jOylJNDzDEh/WOXzPBmTNXLULEt1SfhPpEy8DijZwOCmDCnFCU0kqKSQoHiH8t225bQWifrQF2ceXCoy3HiwMc8jMZvc/ZwpXdlWrQCdJVWunc1EbiJJlyZaV8KgliNxVSvmPWBMHwsQonwdvOHXMLUgUGt3hd5C6KyQmK3P07w80g2S1K+O5irUOcNqHOF0fCxB5xehexgIqi1NQ7wxMK7yFAWuHh0IuStKw9x+kSKoClTyqgSAB9Wi0zWjno6FIsnICiNSQoAUo7XJ94oXgEGqXR/pp7RPvedIdM0GDocK0ZUg3mEeIB+UCLy1YdtKvMgt4WjT1wtcFsKRhTsPp+NCh1cEfl84joQWVcvxBSeHwDPyMdEU66EavGJYeUlAcJSxv+52h7C1OaODQok/djkkFvLiZvGIYjLQHOlqm2op6MfXeOlmyUKHEAX9aWrAX+EpNUKKT677WhqQnBGTKlMRxK0lmLCpLcxsX9Ivx+HVKtMCr0KWIFGdj1i/FYeahgVFbtwkFX5giBps8mi0A6aWII6ULRSk/qJxRbMRMkqQSU1q4JcWehHWC8UibJSFqmKWDQKKlBTs9QoEdYjgcdh1LT9qlzFoAI4FDUCWrs4pBmcTsvUkplHEuAdBUykhVyFJUQpjalrwOcr6LVfBmIzQhNXJ66SHG/wAHzhsRmKpydBDJDqLbkAtT6vFC0pGhWoLccSdKhoIoAaMoMxcdR4zRiiErSXJIYKKtugPlFXYhYoMJQFAEP5s9fMQ8jMZoCj38xJHwhKlAlT9CNKRU+lK0oxC9QSz8KQCTzqfrwghWEV3EtSEkqKppokklLSkg0HwghQ8SYTfRo18szPHKUpJxq5THT96uZ8X8LAEpHMlgHETwub5jMWuWqaj7s6VnEd2UpU5GklYLl0mgexNgTFXacpQpBSA+k6jzWgqlE+Xdgjx6wu0mkFCgSVLKlTK/jSESyWsDqQuGkKxxm2JTPMmZJkCYCUqbCyNQatwn4Wq7s1bRnqzdJNcLh1OTaWUk/wC0j8o0szkEyETq65svDSVaQ6lJ+/1aRudGHkDwU1jA2VyMOhRWszUmUokhSUaSApgCQtwqqaMbHYw1bYNnoWGzqcEIVPTMVOlp7tKgJRRLCmPClVSlISAV6gaKI2jzXtBjUzcRMmaEusuQkqLEgCinqXrbeOpxOey1SlmWRzL1AHUdaDzjhQoGY4AAK3ALEAEuAQaEDrF5KRGOxIC0EKDpUkpI5g1I/KOml5hJxaAmaj7xIoQFHwYps/I+8aeU4CTMkS1rloKlJBUQkJcmpolgPDaCBlMpIOkzEJPxBM2YlJbmAraOP3MU2j2F+EZpRUk13vz+xmyMJIkJlKEsCf3ZK9SiShRUvS6D8KijSWo3SBFKMxfEedz4mN3I8iwkxU0IUEJQjVNVqmL0pGljpBLl1JtzMV4vJ0SpxlmpSfiehBDpaxYgvztGizRaumcuT0GSM9Nk3/p/wc/MQyiDYE29oqEamYYaVLNSXU9i3lUGMlouMlJWjlyYp45OMvIiGh3iMJofCCcTTFbRNMIYxEKJEwodAIIGwhnhzK5RHu4mhpjUiQMMRCaFRVkniWqICHvaFQ7JhcXSsSQ9qwMBE5aoVDsLQQ72LOOQ/WLBLBDPuW84AlrqXFIZSqwqHYaZmz6uuw5xRMmBi9mtz8oq72jRX3RccRbl5wUFmdiMQCVDQAD0Yu4qT5Wigfy3pt8vSNn7Ol3a7uP2i+UhIDHo3lSKsmjFm4NYTqLeX50DAbxFaDQhQLlzQONnJvv+0ak9ekC7dAIEnLClOEavUVtX0hpsGkBlLXAIa462LwXgMeUMOBRulU1Kz3SnUXQUEkg6iSkgpJYkFnhIwbh1KANtO/SG+zIAAUa1t5fvDEHZVPIfVrmqfh0zZahMaumYiY6gl6hSQDxEXZmweaLIXrVJQQrV95LWRX4wgJcAuNWkjiKlG98tWHqwBv7fOCJM6dLFFK0hjpNUvtQ0eC2KkGSMXNxKtKDqmIWJsoFKElXdk8KUpAGopOopcvoodiLjcMoMicgCevirqEyXdkrSKal8iCQNNniIxKVf8yWkk1KgGUTd3iwSZalJKFKlsxqXXqvqCnFXrSCwoy9BZ6saemk1/wByfURPCyDMmIluxWtKH5aiEv5PGnjpU2bMeYtxYKKUoSA7klKBpS5JJ5wNKw81ExKkspQUFJIIUCpJChV+YgsZpKzVCpE1MuWmQUaVSlSxomFOtKCmasVmEhWoqU5dNGBaAEZrOP8AmzB/UTTzizGTZAQsSUrBmEOFgASkAhWhJBOt1AcRAokUcmAJZIdmqGs9Pr8oKT8otZJR/wAW0aGUZjNw87vEqLqB1A1CtwCN2ISryEHnMMRNmhJxC1LVMCVFSU0fd2ranQRjJmGlA70Pjf5ekaOUyFd6FkpAB1HiBc1sASXrCkkSss14bX3C8zytaTrXO7xuYbyZ4AeNDNJ+p4zYcfBm227Y5MJ4aEIYEgYkDEDCBgAmTCiBMKGBpFER7uLoTQ6JsGMmF3cE6YWmFQ7BDKhjLMF6YbRCodgfdQmgwy4gZUKh2DLELRF/dwxTBQ7KGi9POFphm2hUOy8parRAh6N5wkgvFqeUKh2UIlnpeK5uDdyKExoJSmIKQIAMg4Ej9v1iSJDCz+8acwERQpTWh2IECLECGWCfX6pEwsmJPaGSUGUCSTDJw0GISYkEQwBpctQsT8vSJqQD8Sa8xQwQ0SaChWCplEVSr1AJHg4iqYFEuri5vv5iD9ERUmCgszzJTyaEuWDsILUiKyiALKGhNF2iG0QxFTQ7RbphtMIZUqIxYsRXAMUKFCgA2IeN3LMtwpwpxGJXOH3xlASgg2QmY51NzPtEc3ymUkYZWGVMWMRrCRM0pVqSsSwKUDnrFmRiwo0BkmIZ+7ZlIQXUkMqZp0ggmnxp8HrYxH/CJ+tEsyyFzPgSSAS4SrnSihfdxcEAHYDCjQXks8BJKKKmd2OJNVupLXpVCqmlIZGTTyHEst949RTuiEzHrRioDzpAFgDQ2mCcdhFyVmXMGlabhwW3uC0UQqHZHTDFMThQUFlRRC0xbDQqHZGJSoTRICCgscIiaUtEkCLkog1DYEVIJaIjDGNFCGiYlwahsZIwrG0STho0+5iKpEFBsZqpLGGEuNEyYh9lEFCsCEuJCXBYkDlEu6iqFsB93EFS4OMqKlogoLAVIiBRBSkRWUQqHYPohaIv0Q2iCgsoKYgpMEFEVqRAMFnWimL8QIpaJGRh4doeADsMtziSjDnDz8MZye9M0ETlSmJQENwpL0B33iObZ0mYJCZMoyEyNWj7wzC6lBb6ikGh8YeFGhBnqx00p0FZKeGhr8ICUsTUMEpFNgIeZj5qliYqYorDsolyHKlGvUrUf6jChQgFJzCahISmYpIT8IBbT8dRyP3i6j+IxYc2n1HerrU1ueIOeZ4lephQoYA+IxCpiipZdRuWAf0iuFChAKFChQAKFChQAPEkw0KAC+XBCIUKGiWXpiTQoUMQ7QmhQoAE0LTDQoAFphimGhQAQWIHmQoUA0DriswoUSUNDQoUAETEFCFCgAFxQtA7QoUSykSaFChQhn//2Q==";
                        break;
                }
                img = System.Drawing.Image.FromStream(new System.IO.MemoryStream(Convert.FromBase64String(imgBase64)));
            };
            LoadImage();
            TheControl.RemoveFlicker();
            #region(Save an Image to Base64String)
            //MemoryStream ms = new MemoryStream();
            //img.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
            //byte[] imgBytes = ms.ToArray();
            //string imgBase64 = Convert.ToBase64String(imgBytes);
            //File.WriteAllText(@"c:\WOI\jpg_1.txt", imgBase64);
            #endregion

            System.Drawing.Font fnt = new System.Drawing.Font("Calibri", 20);
            float jump = 5.25f;
            Random rand = new Random();
            float angle = 45;
            int tempStop = 0; int tempStopThreshHold = 100;
            int Bars = 5;
            System.Drawing.Drawing2D.LinearGradientBrush lg = new System.Drawing.Drawing2D.LinearGradientBrush(new System.Drawing.Point(0, 0), new System.Drawing.Point(TheControl.Width / 8, TheControl.Height / 8), System.Drawing.Color.Wheat, System.Drawing.Color.Beige);
            lg.InterpolationColors = new System.Drawing.Drawing2D.ColorBlend
            {
                Positions = Enumerable.Range(0, Bars + 1).Select(index => (float)index / (float)(Bars)).ToArray(),
                Colors = Enumerable.Range(0, Bars + 1).Select(index => System.Drawing.Color.FromArgb(rand.Next() % 255, rand.Next() % 255, rand.Next() % 255)).ToArray()
            };
            lg.WrapMode = System.Drawing.Drawing2D.WrapMode.TileFlipX;
            //lg.ScaleTransform(.25f, .25f);
            int x = img.Width / 2; int y = img.Height / 2;
            y = x = (int)Math.Sqrt(img.Width / 2 * img.Width / 2 + img.Height / 2 * img.Height / 2);
            x += xOffset; y += yOffset;

            Action<Graphics> draw = delegate (Graphics grfx)
            {
                grfx.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                grfx.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                grfx.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                grfx.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceOver;
                lg.ResetTransform();

                //lg.SetSigmaBellShape(.25f, .5f);
                lg.RotateTransform(angle);
                grfx.FillRectangle(lg, TheControl.ClientRectangle);

                for (int k = img.Width / 2; k < TheControl.Width + img.Width; k += img.Width)
                {
                    for (int h = img.Height / 2; h < TheControl.Height + img.Height; h += img.Height)
                    {
                        grfx.ResetTransform();
                        grfx.TranslateTransform(k, h);
                        grfx.RotateTransform(-angle);
                        grfx.DrawImage(img, new Point(-img.Width / 2, -img.Height / 2));
                    }
                }
                grfx.ResetTransform();
                int i = xOffset, j = yOffset;
                //int i = 0, j = 0;
                for (int p = 0; p < 5; p++) grfx.DrawString(txt, fnt, Brushes.Yellow, new PointF(i++, j++));
                grfx.DrawString(txt, fnt, Brushes.Black, new PointF(i++, j++));
            };
            int maxAngle = 360; int minAngle = 0;

            TheControl.MouseMove += (se, mmea) =>
            {
                if (holdRotationAt360)
                {
                    if (angle >= maxAngle || angle <= minAngle)
                    {
                        if (angle >= maxAngle) angle = maxAngle;
                        if (angle <= minAngle) angle = minAngle;
                        ++tempStop;
                        if (tempStop >= tempStopThreshHold)
                        {
                            tempStop = 0;
                            jump = -jump;
                            angle += jump;
                            ++s;
                            if (s > 4) s = 0;
                            LoadImage();
                        }
                    }
                    else angle += jump;
                }
                else
                {
                    angle += jump;
                    if (angle >= maxAngle || angle <= minAngle)
                    {
                        jump = -jump;
                        ++s;
                        if (s > 4) s = 0;
                        LoadImage();
                    }
                }
                TheControl.Invalidate();
            };

            TheControl.Paint += (se, pea) => { draw(pea.Graphics); };
            TheControl.Move += (se, mea) =>
            {
                angle += jump;
                TheControl.Invalidate();
            };
            TheControl.SizeChanged += (se, sea) => { angle += jump; TheControl.Invalidate(); };
            //frm.KeyPress += (sender, e) =>
            //{
            //    //if (e.KeyData == System.Windows.Forms.Keys.Escape) frm.Close();
            //};
        }
        static Dictionary<string, UInt64> uinqueIDS = new Dictionary<string, ulong>();
        public static string GetUinqueID(string forWhat)
        {
            UInt64 guid = 0;
            if (uinqueIDS.TryGetValue(forWhat, out guid))
            {
                uinqueIDS[forWhat] = ++guid;
                return (uinqueIDS[forWhat]).ToString();
            }
            else
            {
                uinqueIDS[forWhat] = 0;
                ++uinqueIDS[forWhat];
                return uinqueIDS[forWhat].ToString();
            }
        }
        public static Decimal RoundOff(this Decimal input, int NumberOfDigitsToRoundOffToAfterDecimalPoint)
        {
            return Decimal.Round(input, NumberOfDigitsToRoundOffToAfterDecimalPoint);
        }
        public static System.Data.DataTable ToDataTable<T>(this IList<T> data, string TableName = null)
        {
            System.ComponentModel.PropertyDescriptorCollection props = System.ComponentModel.TypeDescriptor.GetProperties(typeof(T));
            System.Data.DataTable table = new System.Data.DataTable(string.IsNullOrEmpty(TableName) ? "Labamba" : TableName);
            for (int i = 0; i < props.Count; i++)
            {
                System.ComponentModel.PropertyDescriptor prop = props[i];
                table.Columns.Add(prop.Name, prop.PropertyType);
            }
            object[] values = new object[props.Count];
            foreach (T item in data)
            {
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = props[i].GetValue(item);
                }
                table.Rows.Add(values);
            }
            return table;
        }
        public static string GetConfigurationSettings(this string key, string defaultValue, params string[] permissibleValues)
        {
            string configSettings = System.Configuration.ConfigurationManager.AppSettings[key];
            if (String.IsNullOrEmpty(configSettings)) return defaultValue;
            string lowerconfigSettings = configSettings;
            lowerconfigSettings = lowerconfigSettings.ToLower();
            if (permissibleValues == null) return configSettings;
            if (permissibleValues.Any(permissibleValue => (permissibleValue.ToLower() == lowerconfigSettings))) return configSettings;
            return defaultValue;
        }
        static Random rand = new Random();
        public static System.Data.DataTable MakeADataTable(string TableName)
        {
            System.Data.DataTable dt = new System.Data.DataTable(TableName);
            dt.Columns.AddRange(
            Enumerable.Range(0, 5).Select(i =>
            {
                return new System.Data.DataColumn
                {
                    ColumnName = "Name_" + i
                };
            }).ToArray());
            Enumerable.Range(0, rand.Next(15)).ToList().ForEach(i =>
            {
                dt.Rows.Add(Enumerable.Range(0, dt.Columns.Count).Select(j =>
                {
                    if (j == 0) return i.ToString();
                    return "RowData[" + i + "," + j + "]";
                }).ToArray());
            });
            return dt;
        }
        public static String GetRowValue(this DataTable dt, string ColumnName, string forWhat, string fetchColName)
        {
            return
            dt.Rows.Cast<DataRow>().Where(dr =>
            {
                if (!dr.Table.Columns.Contains(ColumnName) || !dr.Table.Columns.Contains(fetchColName)) return false;
                if (dr[ColumnName] == null || string.IsNullOrEmpty(dr[ColumnName].ToString())) return false;
                string lhs = dr[ColumnName].ToString().ToLower();
                return lhs == forWhat.ToLower();
            }).Select(dr =>
            {
                if (dr[fetchColName] == null || string.IsNullOrEmpty(dr[fetchColName].ToString())) return null;
                return dr[fetchColName].ToString();
            }).FirstOrDefault();
        }
        public static string PerformReplacements(this string theString, Dictionary<string, string> otherReplacements = null)
        {
            String returnString = theString;
            if (null == otherReplacements) return returnString;
            foreach (string key in otherReplacements.Keys)
            {
                if (!String.IsNullOrEmpty(otherReplacements[key]))
                {
                    returnString = returnString.Replace(key, otherReplacements[key]);
                }
            }
            return returnString;
        }
        public static Decimal ToDecimalXL(string str, int NumberOfDigitsToRoundOffToAfterDecimalPoint = -1/*-1 means no RoundOff*/)
        {
            if (string.IsNullOrEmpty(str)) return MagicNumbers.ConvertToDecimalIsNull;
            Decimal dCompany = 0m;
            if (!Decimal.TryParse(str, NumberStyles.Float, null, out dCompany))
            {
                return MagicNumbers.ConvertToDecimalIsNotString;
                //return ToDecimalXML(str, NumberOfDigitsToRoundOffToAfterDecimalPoint);
            }
            if (-1 == NumberOfDigitsToRoundOffToAfterDecimalPoint) return dCompany;
            else return dCompany.RoundOff(NumberOfDigitsToRoundOffToAfterDecimalPoint);
        }
        public static Decimal ToDecimalXML(string str, int NumberOfDigitsToRoundOffToAfterDecimalPoint = -1/*-1 means no RoundOff*/)
        {
            if (string.IsNullOrEmpty(str)) return MagicNumbers.ConvertToDecimalIsNull;
            Decimal dCompany = 0m;
            if (!Decimal.TryParse(str, NumberStyles.Any, BasicAction.ci, out dCompany)) return MagicNumbers.ConvertToDecimalIsNotString;
            if (-1 == NumberOfDigitsToRoundOffToAfterDecimalPoint) return dCompany;
            else return dCompany.RoundOff(NumberOfDigitsToRoundOffToAfterDecimalPoint);
        }
        public static string ToString(DataRow obj)
        {
            if (obj.ItemArray[1] == null || obj.ItemArray[1]?.ToString() == "") return "0";
            else return obj.ItemArray[1].ToString();
        }
        public static String DateTimeInThisFormat(/*yyyy-MM-ddThh-mm-ss*/)
        {
            return DateTime.Now.ToString("yyyy-MM-ddThh:mm:ss");
        }
        public static string ToTitleCase(this string str)
        {
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str.ToLower());
        }
        public static System.Data.DataTable RemoveRowsThatAreCompletlyEmpty(this System.Data.DataTable dt)
        {
            var ret = dt.Rows.Cast<System.Data.DataRow>().Where(row => !row.ItemArray.All(field => field is DBNull || string.IsNullOrWhiteSpace(field as string)));
            var retDT = ret.CopyToDataTable();
            //var retDT = System.Data.DataTableExtensions.CopyToDataTable(ret);
            retDT.TableName = dt.TableName;
            return retDT;
        }
        public static System.Data.DataTable RemoveRowsThatContain(this System.Data.DataTable dt, String str)
        {
            var ret = dt.Rows.Cast<System.Data.DataRow>().Where(dr =>
            {
                bool whatHappened = false;
                for (int i = 0; i < dt.Columns.Count; ++i)
                {
                    if (!(dr[i] is DBNull) && dr[i] != null && dr[i].ToString() == str) whatHappened = true;
                }
                return whatHappened;
            });
            var retDT = ret.CopyToDataTable();
            retDT.TableName = dt.TableName;
            return retDT;
        }
        public static System.Data.DataTable RemoveRowsThatContain(this System.Data.DataTable dt, String str, int ColumnIndex)
        {
            var ret = dt.Rows.Cast<System.Data.DataRow>().Where(dr =>
            {
                bool whatHappened = false;
                if (!(dr[ColumnIndex] is DBNull) && dr[ColumnIndex] != null && dr[ColumnIndex].ToString() == str) whatHappened = true;
                return whatHappened;
            });
            var retDT = ret.CopyToDataTable();
            retDT.TableName = dt.TableName;
            return retDT;
        }
        public static List<double> maxColWidths(this System.Data.DataTable dt)
        {
            List<double> maxWidths = new List<double>();
            for (int i = 0; i < dt.Columns.Count; ++i) maxWidths.Add(dt.Rows.Cast<DataRow>().Max(dr => dr[i].ToString().Length));
            return maxWidths;
        }
        public static IEnumerable<System.Data.DataTable> GroupBy(this System.Data.DataTable dt, String dtColumnname, bool isCaseSensitive = false)
        {
            return dt.Rows.Cast<System.Data.DataRow>().GroupBy(dr => isCaseSensitive ? dr[dtColumnname] : dr[dtColumnname].ToString().ToLower().ToTitleCase()).Select(grp =>
              {
                  var dtGrp = grp.CopyToDataTable();
                  dtGrp.TableName = grp.Key.ToString();
                  return dtGrp;
              });
        }
        public static System.Data.DataTable RemoveRowsThatHaveAtLeastOnCellEmpty(this System.Data.DataTable dt)
        {
            var ret = dt.Rows.Cast<System.Data.DataRow>().Where(row => !row.ItemArray.Any(field => field is DBNull || string.IsNullOrWhiteSpace(field as string)));
            var retDT = ret.CopyToDataTable();
            retDT.TableName = dt.TableName;
            return retDT;
        }
        public static System.Data.DataTable RemoveRowsThatHaveAtLeastThisCellEmpty(this System.Data.DataTable dt, string ColumnName)
        {
            try
            {
                var ret = dt.Rows.Cast<System.Data.DataRow>().Where(row => !(row[ColumnName] is DBNull || String.IsNullOrEmpty(row[ColumnName].ToString())));
                var retDT = ret.CopyToDataTable();
                retDT.TableName = dt.TableName;
                return retDT;
            }
            catch (Exception ex)
            {
                System.Data.DataRow dr = dt.Rows[0];
                string exists = dr.Table.Columns.Contains(ColumnName) ? "♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥\nSome major issue\n♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥\n" : "♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥\nSuch a column\"" + ColumnName + "\" does not exists\nReturning your old table\n♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥\n";
                (exists + ex.ProcessException()).Show("OOps Utils RemoveRowsThatHaveAtLeastThisCellEmpty damar");
                return dt;
            }
        }
        public static string ForwardExtractStartingFrom(this string strBone, int ForwardStartIndex, char stoppingCharacter = ' ') //what column u c in Notepad++
        {
            if (strBone.Length <= 0 || ForwardStartIndex <= 0 || strBone.Length < ForwardStartIndex) return null;

            int ForwardEndIndex = -1;
            for (int i = ForwardStartIndex - 1; i < strBone.Length; ++i)
            {
                if (strBone[i] == stoppingCharacter)
                {
                    ForwardEndIndex = i + 1;
                    break;
                };
            }
            if (ForwardEndIndex == -1) return null;
            return strBone.Substring(ForwardStartIndex - 1, ForwardEndIndex - ForwardStartIndex);
        }
        public static string BackwardExtractStartingFrom(this string strBone, int BackwardStartIndex, char stoppingCharacter = ' ')//what column u c in Notepad++
        {
            if (strBone.Length <= 0 || BackwardStartIndex <= 0 || strBone.Length < BackwardStartIndex) return null;
            int BaackwardEndIndex = -1;
            for (int i = BackwardStartIndex - 2; i >= 0; --i)
            {
                if (strBone[i] == stoppingCharacter)
                {
                    BaackwardEndIndex = i;
                    break;
                };
            }
            if (BaackwardEndIndex == -1) return null;
            return strBone.Substring(BaackwardEndIndex, BackwardStartIndex - BaackwardEndIndex);
        }
        public static bool isInteger(this string input)
        {
            int n = 0;
            return int.TryParse(input, out n);
        }
        public static string GetDataRowValue(System.Data.DataRow dr, string ColumnName, bool ToLowerCase = false)
        {
            try
            {
                if (dr.IsNull(ColumnName)) return null;
                string columnVal = dr[ColumnName].ToString().Trim();
                if (ToLowerCase) return columnVal.ToLower();
                return columnVal;
            }
            catch (Exception ex)
            {
                string exists = dr.Table.Columns.Contains(ColumnName) ? "♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥\nSome major issue\n♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥\n" : "♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥\nSuch a column\"" + ColumnName + "\" does not exists\n♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥\n";
                (exists + ex.ProcessException()).Show("OOps Utils GetDataRowValue damar");
                return null;
            }
        }
        public static bool GetValueStatus(System.Data.DataRow dr, string ColumnName)
        {
            try
            {
                if (dr.IsNull(ColumnName)) return false;
                return true;
            }
            catch (Exception ex)
            {
                string exists = dr.Table.Columns.Contains(ColumnName) ? "♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥\nSome major issue\n♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥\n" : "♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥\nSuch a column\"" + ColumnName + "\" does not exists\n♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥\n";
                (exists + ex.ProcessException()).Show("OOps Utils GetValueStatus damar");
                return false;
            }
        }
        public static IsFileInUseStatus GetFileStatus(this string filePath, string x10s = null)
        {
            string extension = System.IO.Path.GetExtension(filePath);
            if (!String.IsNullOrEmpty(x10s) && !x10s.Contains(extension.ToLower())) return IsFileInUseStatus.WrongExtension;

            if (!System.IO.File.Exists(filePath)) return IsFileInUseStatus.FileNotFound;
            try
            {
                using (System.IO.FileStream fs = new System.IO.FileStream(filePath, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.None)) { fs.Close(); fs.Dispose(); }
                return IsFileInUseStatus.FileNotOpenByAnotherProcess;
            }
            catch //(System.IO.IOException ioex)
            {
                return IsFileInUseStatus.FileOpenedByAnotherProcess;
            }
        }
        public static string GetCurrentIP()
        {
            //return "127.0.0.1";
            System.Net.IPAddress[] ipAdd = System.Net.Dns.GetHostAddresses(System.Net.Dns.GetHostName());
            string stLocalIP = "";

            Enumerable.Range(0, ipAdd.Length).Any(index =>
            {
                if (ipAdd[index].AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    stLocalIP = ipAdd[index].ToString();
                    return true;
                }
                return false;
            });
            return stLocalIP;
        }
        public static void ExploreFile(this string filePath) { System.Diagnostics.Process.Start("explorer.exe", string.Format("/select,\"{0}\"", filePath)); }
        //public static void DownloadFile(this string url, string fname)
        //{
        //    System.Net.WebClient wc = new System.Net.WebClient();
        //    if (!File.Exists(fname)) wc.DownloadFile(url, fname);
        //}
        //public static void DownloadFiles(this List<string> urls, List<string> fnames)
        //{
        //    if (urls.Count != fnames.Count) return;
        //    int i = 0;
        //    using (System.Net.WebClient wc = new System.Net.WebClient()) urls.ForEach(url => { if (!File.Exists(fnames[i])) wc.DownloadFile(url, fnames[i]); i++; });
        //}
        public static void MakeResizable(this Control control)
        {
            int dwCurStyle = Helper.GetWindowLong(control.Handle, GWL_STYLE);
            dwCurStyle = dwCurStyle | Helper.WS_RESIZABLE;
            Helper.SetWindowLong(control.Handle, GWL_STYLE, dwCurStyle);
        }
        public static void AddCaption(this Control control)
        {
            int dwCurStyle = Helper.GetWindowLong(control.Handle, GWL_STYLE);
            dwCurStyle = dwCurStyle | Helper.WS_RESIZABLE | Helper.WS_CAPTION | WS_MINIMIZEBOX | WS_SYSMENU;
            Helper.SetWindowLong(control.Handle, GWL_STYLE, dwCurStyle);
        }
        public static void FadeIn(this System.Windows.Forms.Form frm)
        {
            frm.Opacity = 0;
            new System.Threading.Tasks.Task(() =>
            {
                System.Threading.Thread.Sleep(1000);
                frm.Invoke((MethodInvoker)delegate
                {
                    double jump = .01;
                    while (true)
                    {
                        frm.Opacity += jump;
                        if (frm.Opacity >= 1)
                        {
                            frm.Activate();
                            break;
                        }
                        Application.DoEvents();
                        System.Threading.Thread.Sleep(10);
                    }
                });
            }).Start();
        }
        public static void FadeOut(this System.Windows.Forms.Form frm, bool toClose = false)
        {
            System.Threading.Thread.Sleep(500);
            double jump = .01;
            while (true)
            {
                frm.Opacity -= jump;
                Application.DoEvents();
                System.Threading.Thread.Sleep(10);
                if (frm.Opacity < .1) break;
            }
            if (toClose) frm.Close();
        }
        //#region Grouped Zip


        ///// <summary>
        ///// Zips the specified input files to output path.
        ///// </summary>
        ///// <param name="inputPathname">The input pathname.</param>
        ///// <param name="outputPathname">The output pathname.</param>
        //public static void Zip(this string inputPathname, string outputPathname)
        //{
        //    CreateGroupedZip(outputPathname, "", inputPathname);
        //}

        ///// <summary>
        ///// Compresses the files in the nominated folder, and creates a zip file on disk named as outPathname.
        ///// </summary>
        ///// <param name="outputPathname"></param>
        ///// <param name="password"></param>
        ///// <param name="inputPathname"></param>
        //public static void CreateGroupedZip(string outputPathname, string password, string inputPathname)
        //{

        //    FileStream fsOut = File.Create(outputPathname);
        //    ZipOutputStream zipStream = new ZipOutputStream(fsOut);

        //    zipStream.SetLevel(3); //0-9, 9 being the highest level of compression

        //    zipStream.Password = password;  // optional. Null is the same as not setting. Required if using AES.

        //    // This setting will strip the leading part of the folder path in the entries, to
        //    // make the entries relative to the starting folder.
        //    // To include the full path for each entry up to the drive root, assign folderOffset = 0.
        //    int folderOffset = inputPathname.Length + (inputPathname.EndsWith("\\") ? 0 : 1);

        //    CompressFolder(inputPathname, zipStream, folderOffset);

        //    zipStream.IsStreamOwner = true; // Makes the Close also Close the underlying stream
        //    zipStream.Close();
        //}

        //private static void CompressFolder(string Inputpathname, ZipOutputStream zipStream, int folderOffset)
        //{
        //    string[] files = Directory.GetFiles(Inputpathname);
        //    foreach (string filename in files)
        //    {

        //        System.IO.FileInfo fi = new System.IO.FileInfo(filename);
        //        string entryName = filename.Substring(folderOffset); // Makes the name in zip based on the folder
        //        entryName = ZipEntry.CleanName(entryName); // Removes drive from name and fixes slash direction
        //        ZipEntry newEntry = new ZipEntry(entryName);
        //        newEntry.DateTime = fi.LastWriteTime; // Note the zip format stores 2 second granularity

        //        // Specifying the AESKeySize triggers AES encryption. Allowable values are 0 (off), 128 or 256.
        //        // A password on the ZipOutputStream is required if using AES.
        //        //   newEntry.AESKeySize = 256;

        //        // To permit the zip to be unpacked by built-in extractor in WinXP and Server2003, WinZip 8, Java, and other older code,
        //        // you need to do one of the following: Specify UseZip64.Off, or set the Size.
        //        // If the file may be bigger than 4GB, or you do not need WinXP built-in compatibility, you do not need either,
        //        // but the zip will be in Zip64 format which not all utilities can understand.
        //        //   zipStream.UseZip64 = UseZip64.Off;
        //        newEntry.Size = fi.Length;

        //        zipStream.PutNextEntry(newEntry);

        //        // Zip the file in buffered chunks
        //        // the "using" will close the stream even if an exception occurs
        //        byte[] buffer = new byte[4096];
        //        using (FileStream streamReader = File.OpenRead(filename))
        //        {
        //            StreamUtils.Copy(streamReader, zipStream, buffer);
        //        }
        //        zipStream.CloseEntry();
        //    }
        //    string[] folders = Directory.GetDirectories(Inputpathname);
        //    foreach (string folder in folders)
        //    {
        //        CompressFolder(folder, zipStream, folderOffset);
        //    }
        //}

        //public static void ExtractZipFile(this string archiveFilenameIn, string password, string outFolder)
        //{
        //    ZipFile zf = null;
        //    try
        //    {
        //        FileStream fs = File.OpenRead(archiveFilenameIn);
        //        zf = new ZipFile(fs);
        //        if (!String.IsNullOrEmpty(password))
        //        {
        //            zf.Password = password;		// AES encrypted entries are handled automatically
        //        }
        //        foreach (ZipEntry zipEntry in zf)
        //        {
        //            if (!zipEntry.IsFile)
        //            {
        //                continue;			// Ignore directories
        //            }
        //            String entryFileName = zipEntry.Name;
        //            // to remove the folder from the entry:- entryFileName = Path.GetFileName(entryFileName);
        //            // Optionally match entrynames against a selection list here to skip as desired.
        //            // The unpacked length is available in the zipEntry.Size property.

        //            byte[] buffer = new byte[4096];		// 4K is optimum
        //            Stream zipStream = zf.GetInputStream(zipEntry);

        //            // Manipulate the output filename here as desired.
        //            String fullZipToPath = Path.Combine(outFolder, entryFileName);
        //            string directoryName = Path.GetDirectoryName(fullZipToPath);
        //            if (directoryName.Length > 0)
        //                Directory.CreateDirectory(directoryName);

        //            // Unzip file in buffered chunks. This is just as fast as unpacking to a buffer the full size
        //            // of the file, but does not waste memory.
        //            // The "using" will close the stream even if an exception occurs.

        //                using (FileStream streamWriter = File.Create(fullZipToPath))
        //                {
        //                    StreamUtils.Copy(zipStream, streamWriter, buffer);
        //                }                   

        //        }
        //    }
        //    finally
        //    {
        //        if (zf != null)
        //        {
        //            zf.IsStreamOwner = true; // Makes close also shut the underlying stream
        //            zf.Close(); // Ensure we release resources
        //        }
        //    }
        //}
        //#endregion



        //public static bool IsFileinUse(string fileName)
        //{
        //    FileInfo file = new FileInfo(fileName);
        //    try
        //    {
        //        using (FileStream stream = file.Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None))
        //        {
        //            stream.Close();
        //            return false;
        //        }
        //    }
        //    catch
        //    {
        //        //the file is unavailable because it is:
        //        //still being written to
        //        //or being processed by another thread
        //        //or does not exist (has already been processed)
        //        //ex.ProcessException();
        //        return true;
        //    }
        //}
    }
    public class AppUtils
    {
        public static bool IsAnotherInstanceRunning()
        {
            try
            {
                BasicAction.appMutex = System.Threading.Mutex.OpenExisting(Utils.BasicAction.MutexName);
                return true;
            }
            catch
            {
                BasicAction.appMutex = new System.Threading.Mutex(true, Utils.BasicAction.MutexName);
                return false;
            }
        }
        public static void WaitUntilDark()
        {
            new System.Threading.Tasks.Task(() =>
            {
                try { BasicAction.manualResetEvent = System.Threading.EventWaitHandle.OpenExisting(BasicAction.ManualResetEventName); }
                catch
                {
                    BasicAction.manualResetEvent = new System.Threading.EventWaitHandle(false, System.Threading.EventResetMode.ManualReset, BasicAction.ManualResetEventName);
                    BasicAction.manualResetEvent.WaitOne();
                    System.Windows.Forms.Application.Exit();
                }
            }).Start();
        }
        public static void InitializeApplicationEvents()
        {
            AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
            {
                try
                {
                    String resourceName = BasicAction.nsAppreferencesFolder + new System.Reflection.AssemblyName(args.Name).Name + ".dll";
                    using (var stream = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
                    {
                        if (stream == null) return null;
                        Byte[] assemblyData = new Byte[stream.Length];
                        stream.Read(assemblyData, 0, assemblyData.Length);
                        return System.Reflection.Assembly.Load(assemblyData);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ProcessException(), "Bad Boy");
                    return null;
                }
            };
        }
        public static void SetupExceptionHandling()
        {
            AppDomain.CurrentDomain.UnhandledException += (s, e) => MessageBox.Show(((Exception)(e.ExceptionObject)).ProcessException(), "A Catastrophic exception !!!!");
            Application.ThreadException += (s, e) => { MessageBox.Show(e.Exception.ProcessException(), "An Unforseen exception !!!!"); };
        }
    }
    public static class XMLSerializationUtils
    {
        private class Utf8StringWriter : System.IO.StringWriter { public override Encoding Encoding { get { return System.Text.Encoding.UTF8; } } }
        public static string ToXML<T>(this T SerializableObject, Dictionary<String, string> nameSpaceMappings = null)
        {
            //Regex regex = new Regex(@"(\s)*<(\w)*(\s)*/>");
            System.Xml.Serialization.XmlSerializer xmlSerializer = new System.Xml.Serialization.XmlSerializer(SerializableObject.GetType());
            System.Xml.Serialization.XmlSerializerNamespaces xmlns = null;
            if (nameSpaceMappings != null)
            {
                xmlns = new System.Xml.Serialization.XmlSerializerNamespaces();
                foreach (string k in nameSpaceMappings.Keys) xmlns.Add(k, nameSpaceMappings[k]);
            }
            XmlDocument XDoc = new XmlDocument();

            using (Utf8StringWriter textWriter = new Utf8StringWriter())
            {
                xmlSerializer.Serialize(textWriter, SerializableObject, xmlns);
                return textWriter.ToString().Replace("xmlns:schemaLocation", "xsi:schemaLocation");
                //return regex.Replace(textWriter.ToString().Replace("xmlns:schemaLocation", "xsi:schemaLocation"), string.Empty);
            }

        }
        public static T DeserializeXMLFileToObject<T>(string XmlFilename)
        {
            T returnObject = default(T);
            if (string.IsNullOrEmpty(XmlFilename)) return default(T);
            try
            {
                System.IO.StreamReader xmlStream = new System.IO.StreamReader(XmlFilename);
                System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(T));
                returnObject = (T)serializer.Deserialize(xmlStream);
            }
            catch (Exception ex)
            {

                ex.ProcessException().Show("issue @ DeserializeXMLFileToObject");
            }
            return returnObject;
        }
    }
    public static class XMLUtils
    {
        public static string AttributeExtract(this System.Xml.Linq.XElement element, string attribute, string defaultValue = null)
        {
            if (String.IsNullOrEmpty(attribute)) return null;
            System.Xml.Linq.XAttribute theAttribute = element.Attribute(attribute);
            return (theAttribute == null) ? null : theAttribute.Value;
        }
        public static string AttributeToExtract(System.Xml.Linq.XElement element, string attribute, string defaultValue = null)
        {
            if (String.IsNullOrEmpty(attribute) || element == null) return null;
            var theAttribute = element.Attribute(attribute);
            return (theAttribute == null) ? null : theAttribute.Value;
        }
        public static string FirstDescendentAttributeExtract(this System.Xml.Linq.XElement ParentElement, string DescendantNodeName, string DescendantNodeAttribute, string defaultValue = null)
        {
            if (ParentElement == null || String.IsNullOrEmpty(DescendantNodeName) || String.IsNullOrEmpty(DescendantNodeAttribute)) return null;
            var FirstDescendantElement = ParentElement.Descendants(DescendantNodeName).FirstOrDefault();
            if (FirstDescendantElement == null) return null;
            return FirstDescendantElement.AttributeExtract(DescendantNodeAttribute, defaultValue);
        }
        public static string FirstDescendentsFirstDescendentAttributeExtract(this System.Xml.Linq.XElement ParentElement, String FirstChildNodeName,
            String FirstChildsFirstDescendantNodeName, string FirstChildsFirstDescendantNodeAttribute, string defaultValue = null)
        {
            if (ParentElement == null || String.IsNullOrEmpty(FirstChildNodeName) || String.IsNullOrEmpty(FirstChildsFirstDescendantNodeName) ||
                String.IsNullOrEmpty(FirstChildsFirstDescendantNodeAttribute)) return null;
            var FirstDescendantOfParentElement = ParentElement.Descendants(FirstChildNodeName).FirstOrDefault();
            if (FirstDescendantOfParentElement == null) return null;
            return FirstDescendantOfParentElement.FirstDescendentAttributeExtract(FirstChildsFirstDescendantNodeName, FirstChildsFirstDescendantNodeAttribute);
        }
        public static string HierarchicalFirstChildAttributeExtract(this System.Xml.Linq.XElement ParentElement, string childNodeAttributeName, params string[] namesOfNodeLeadingToTheChildNode)
        {
            if (String.IsNullOrEmpty(childNodeAttributeName) || childNodeAttributeName == null || childNodeAttributeName.Length <= 0) return null;
            System.Xml.Linq.XElement childNode = null;
            System.Xml.Linq.XElement StepFather = ParentElement;
            foreach (String childNodeName in namesOfNodeLeadingToTheChildNode)
            {
                childNode = StepFather.Descendants(childNodeName).FirstOrDefault();
                if (childNode == null) return null;
                StepFather = childNode;
            }
            return childNode.AttributeExtract(childNodeAttributeName);
        }
        public static System.Xml.Linq.XElement Closest(this System.Xml.Linq.XElement childElement, string tag)
        {
            //usage
            //string xml = @"<note>
            //                    <to>Tove</to>
            //                    <from>
            //                        <heading>
            //                            <body>Don't forget me this weekend!</body>
            //                            Reminder
            //                        </heading>
            //                    Jani
            //                    </from>
            //               </note>";
            //XDocument xDoc = XDocument.Parse(xml);
            //var root = xDoc.Root;
            //string name = root.Name.ToString();
            //var thebodyNode = root.Descendants("body").FirstOrDefault();
            /************************ BEST WAY ************************/
            ////var nm = thebodyNode.AncestorsAndSelf("from1").FirstOrDefault();
            ////var nm = thebodyNode.AncestorsAndSelf("from").FirstOrDefault();
            //var nm = thebodyNode.AncestorsAndSelf("note").FirstOrDefault();
            /************************ BEST WAY ************************/

            //name = nm?.Name.ToString();
            //var cNode = thebodyNode.Closest("note");
            //var cNode = thebodyNode.Closest("body");
            //var cNode = thebodyNode.Closest("from");
            //var cNode = thebodyNode.Closest("from1");
            //name = cNode?.Name.ToString();

            var parent = childElement;
            while (true)
            {
                if (parent == null) return null;
                if (String.Compare(parent.Name.ToString(), tag, true) == 0) return parent;
                parent = parent.Parent;
            }
        }
    }
    public static class XSLUtils
    {
        public static System.Xml.Linq.XDocument ApplyXSL(this System.Xml.Linq.XDocument sourceXDoc, string xslMarkup)
        {
            System.Xml.Linq.XDocument newTree = new System.Xml.Linq.XDocument();
            using (System.Xml.XmlWriter writer = newTree.CreateWriter())
            {
                // Load the style sheet.  
                System.Xml.Xsl.XslCompiledTransform xslt = new System.Xml.Xsl.XslCompiledTransform();
                xslt.Load(System.Xml.XmlReader.Create(new System.IO.StringReader(xslMarkup)));

                // Execute the transform and output the results to a writer.  
                xslt.Transform(sourceXDoc.CreateReader(), writer);
            }
            return newTree;
        }
    }
    public static class EmbeddedResourceUtils
    {
        //public static bool CopyFromResourceInSetupToDestination(this string resourceSourcefilename, string destinationstrFilePath)
        //{
        //    try
        //    {
        //        System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceSourcefilename).SaveStream(destinationstrFilePath);
        //    }
        //    catch (Exception ex)
        //    {
        //        ex.ProcessException();
        //        return false;
        //    }
        //    return true;
        //}
        //public static bool CopyFromResourceInSetupToDestinationAndDownload(this string resourceSourcefilename, ref string destinationstrFilePath, bool toPromptForSaveFileDialog = false, bool toOpen = false)
        //{
        //    try
        //    {
        //        if (toPromptForSaveFileDialog)
        //        {
        //            SaveFileDialog sfd = new SaveFileDialog();
        //            sfd.InitialDirectory = Path.GetDirectoryName(destinationstrFilePath);
        //            sfd.Filter = "Project files (*.xlsx)|*.xlsx";
        //            sfd.FileName = Path.GetFileName(destinationstrFilePath);
        //            if (sfd.ShowDialog() != DialogResult.OK) return false;
        //            destinationstrFilePath = sfd.FileName;
        //        }
        //        System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceSourcefilename).SaveStream(destinationstrFilePath);
        //        Helper.ShellExecute(IntPtr.Zero, "open", destinationstrFilePath, "", "", 1);
        //    }
        //    catch (Exception ex)
        //    {
        //        ex.ProcessException();
        //        return false;
        //    }
        //    return true;
        //}
        public static string CopyFromAppReferencesToDestinationAndDownload(this string resourceSourcefilename, ref string destinationstrFilePath, bool toPromptForSaveFileDialog = false, bool toOpen = false)
        {
            try
            {
                if (toPromptForSaveFileDialog)
                {
                    System.Windows.Forms.SaveFileDialog sfd = new System.Windows.Forms.SaveFileDialog();

                    sfd.Filter = "Project files (*.xlsx)|*.xlsx";
                    sfd.FileName = System.IO.Path.GetFileName(destinationstrFilePath);
                    sfd.InitialDirectory = System.IO.Path.GetDirectoryName(destinationstrFilePath);
                    if (sfd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return null;
                    destinationstrFilePath = sfd.FileName;
                }
                //Helper.ShellExecute(IntPtr.Zero, "open", destinationstrFilePath, "", "", 1);
                if ((destinationstrFilePath).GetFileStatus() == IsFileInUseStatus.FileOpenedByAnotherProcess)
                {
                    DialogResult Result = MessageBox.Show("FileInUse", "Alert", MessageBoxButtons.OK);
                    if (Result == DialogResult.OK && destinationstrFilePath.GetFileStatus() == IsFileInUseStatus.FileOpenedByAnotherProcess) return null;
                }
                System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceSourcefilename).SaveStream(destinationstrFilePath);
            }
            catch (Exception ex)
            {
                ex.ProcessException().Show("issue @ CopyFromAppReferencesToDestinationAndDownload");
                return null;
            }
            return destinationstrFilePath;
        }
        private static bool SaveStream(this System.IO.Stream input, string destinationstrFilePath)
        {
            try
            {
                using (System.IO.FileStream fs = new System.IO.FileStream(destinationstrFilePath, System.IO.FileMode.Create))
                {
                    input.CopyTo(fs);
                    fs.Close();
                    fs.Dispose();
                }
                return true;
            }
            catch (Exception ex)
            {
                ex.ProcessException().Show("issue @ SaveStream");
                return false;
            }
        }

        public static void CopyAllEmbeddedResources(this String[] appReferencesResources, bool alwaysCopy = false)
        {
            if (alwaysCopy) foreach (String resToBeCopied in appReferencesResources) File.Delete(resToBeCopied);
            System.Threading.Thread.Sleep(1000);
            foreach (String resToBeCopied in appReferencesResources)
            {
                String res = resToBeCopied;
                if (!File.Exists(res)) (BasicAction.nsAppreferencesFolder + res).CopyFromAppReferencesToDestinationAndDownload(ref res);
            }
        }
    }
    public static class ByteExtensions
    {
        public static bool EndsWith(this List<byte> bytes, string token)
        {
            int byteCount = bytes.Count;
            int tokenCount = token.Length;
            if (byteCount < tokenCount) return false;
            return bytes.Skip(byteCount - tokenCount).SequenceEqual(token.Select(ch => (byte)ch));
        }
        public static byte[] FromThisToThat(this byte[] bytes, string thisToken, string thatToken)
        {
            int startIndex = bytes.firstOccurrenceOf(thisToken);
            int endEndex = bytes.firstOccurrenceOfAfterIndex(thatToken, startIndex + thisToken.Length);
            if (startIndex == -1 || endEndex == -1 || startIndex >= endEndex) return null;
            return bytes.Skip(startIndex).Take(endEndex - startIndex).ToArray();
        }
        public static byte[] GetEverythingUntil(this byte[] bytes, int lastBytes)
        {
            byte[] bakar = new byte[bytes.Length - lastBytes];
            Array.Copy(bytes, 0, bakar, 0, bakar.Length);
            return bakar;
        }
        public static byte[] GetEverythingAfterTheNthOccurrence(this byte[] bytes, string token, int n)
        {
            int index = bytes.nThOccurrenceOf(token, n);
            if (index == -1) return null;
            index += token.Length;
            byte[] bakar = new byte[bytes.Length - index];
            Array.Copy(bytes, index, bakar, 0, bakar.Length);
            return bakar;
        }
        public static byte[] GetUntilFirstOccurrenceOf(this byte[] bytes, string token)
        {
            int index = bytes.firstOccurrenceOf(token);
            if (index == -1) return null;
            byte[] babar = new byte[index];
            Array.Copy(bytes, 0, babar, 0, babar.Length);
            return babar;
        }
        public static byte[] TrimEnd(this byte[] bytes, string token)
        {
            var lastFewBytes = bytes.Skip(bytes.Length - token.Length).Take(token.Length);
            if (lastFewBytes.SequenceEqual(token.Select(x => (byte)x))) return bytes.Take(bytes.Length - token.Length).ToArray();
            return null;
        }
        public static int firstOccurrenceOfAfterIndex(this byte[] bytes, string token, int afterIndex)
        {
            if (afterIndex < 0) return -1;
            for (int i = afterIndex; i <= bytes.Length - token.Length; i++)
            {
                int found = 0;
                int z = 0;
                for (z = 0; z < token.Length; z++)
                {
                    if (bytes[i + z] == (byte)token[z]) found++;
                    else
                    {
                        found--;
                        break;
                    }
                }
                if (found == token.Length) return (i);
            }
            return -1;
        }
        public static int firstOccurrenceOf(this byte[] bytes, string token)
        {
            for (int i = 0; i <= bytes.Length - token.Length; i++)
            {
                int found = 0;
                int z = 0;
                for (z = 0; z < token.Length; z++)
                {
                    if (bytes[i + z] == (byte)token[z]) found++;
                    else
                    {
                        found--;
                        break;
                    }
                }
                if (found == token.Length) return i;
            }
            return -1;
        }
        static int nThOccurrenceOf(this byte[] bytes, string token, int n)
        {
            int loopCount = 0;
            List<int> indices = new List<int>();
            for (int i = 0; i <= bytes.Length - token.Length; i++)
            {
                int found = 0;
                int z = 0;
                for (z = 0; z < token.Length; z++)
                {
                    if (bytes[i + z] == (byte)token[z]) found++;
                    else
                    {
                        found--;
                        break;
                    }
                }
                if (found == token.Length)
                {
                    loopCount++;
                    indices.Add(i);
                }
                if (loopCount > n) return indices[indices.Count - 1];
            }
            return -1;
        }
        static List<int> allIndicesOf(this byte[] bytes, string token)
        {
            List<int> indices = new List<int>();
            for (int i = 0; i < bytes.Length - token.Length; i++)
            {
                int found = 0;
                int z = 0;
                for (z = 0; z < token.Length; z++)
                {
                    if (bytes[i + z] == (byte)token[z]) found++;
                    else
                    {
                        found--;
                        break;
                    }
                }
                if (found == token.Length) indices.Add(i);
            }
            return indices;
        }
        public static List<List<byte>> ByteSplit_old(this byte[] bytes, string token)
        {
            List<int> indices = bytes.allIndicesOf(token);
            if (indices == null || indices.Count <= 0) return null;

            List<List<byte>> lo = new List<List<byte>>();
            int p = 0;
            int n = indices[0];
            for (int i = 0; i < indices.Count; i++)
            {
                n = indices[i];
                List<byte> bTmp = new List<byte>();

                for (int j = p; j < n; j++) bTmp.Add(bytes[j]);
                lo.Add(bTmp);
                p = n + token.Length;
            }
            if (indices[indices.Count - 1] < bytes.Length)
            {
                List<byte> bTmp = new List<byte>();

                for (int j = indices[indices.Count - 1] + token.Length; j < bytes.Length; j++)
                {
                    bTmp.Add(bytes[j]);
                }
                lo.Add(bTmp);
            }
            return lo;
        }
        public static List<byte[]> ByteSplit(this byte[] bytes, string token)
        {
            List<int> indices = bytes.allIndicesOf(token);
            if (indices == null || indices.Count <= 0) return null;

            List<byte[]> lo = new List<byte[]>();
            int p = 0;
            int n = indices[0];
            for (int i = 0; i < indices.Count; i++)
            {
                n = indices[i];
                byte[] kutiPapa = new byte[n - p];
                Array.Copy(bytes, p, kutiPapa, 0, kutiPapa.Length);
                lo.Add(kutiPapa);
                p = n + token.Length;
            }
            if (indices[indices.Count - 1] < bytes.Length)
            {
                List<byte> bTmp = new List<byte>();
                p = indices[indices.Count - 1] + token.Length;
                n = bytes.Length;
                byte[] kutiPapa = new byte[n - p];
                Array.Copy(bytes, p, kutiPapa, 0, kutiPapa.Length);
                lo.Add(kutiPapa);
            }
            return lo;
        }
        public static List<Point> ByteSplitIndices(this byte[] bytes, string token)
        {
            List<int> indices = bytes.allIndicesOf(token);
            if (indices == null || indices.Count <= 0) return null;

            List<Point> lo = new List<Point>();
            int p = 0;
            int n = indices[0];
            for (int i = 0; i < indices.Count; i++)
            {
                n = indices[i];
                lo.Add(new Point(p, n));
                p = n + token.Length;
            }
            if (indices[indices.Count - 1] < bytes.Length)
            {
                List<byte> bTmp = new List<byte>();
                p = indices[indices.Count - 1] + token.Length;
                n = bytes.Length;
                lo.Add(new Point(p, n));
            }
            return lo;
        }
    }
    public static class SocketExtensions
    {
        public static byte[] ReceiveUntil(this System.Net.Sockets.Socket handler, string token, int recBufferSize = 1024)
        {
            List<byte> finalBytes = new List<byte>();
            while (true)
            {
                byte[] recBytes = new byte[recBufferSize];
                int CountReceived = handler.Receive(recBytes);
                if (CountReceived <= 0) return null;
                byte[] actuallyReceivedBytes = (CountReceived == recBytes.Length) ? recBytes : recBytes.Take(CountReceived).ToArray();
                byte[] protocolBytes = actuallyReceivedBytes.GetUntilFirstOccurrenceOf(token);
                if (protocolBytes == null) finalBytes.AddRange(actuallyReceivedBytes);//did not find so keep receiving
                else // means u found the protocol terminating token
                {
                    finalBytes.AddRange(protocolBytes);
                    return finalBytes.ToArray();
                }
                //Note: I discard whatever appears after the token, as it seems meaning less. (Sandeep and KASI please ponder over this)
            }
        }
        public static byte[] ReceiveOneShotUntil(this System.Net.Sockets.Socket handler, string token, int recBufferSize = 1024)
        {
            byte[] recBytes = new byte[recBufferSize];
            int CountReceived = handler.Receive(recBytes);
            if (CountReceived <= 0) return null;
            byte[] actuallyReceivedBytes = (CountReceived == recBytes.Length) ? recBytes : recBytes.Take(CountReceived).ToArray();
            byte[] protocolBytes = actuallyReceivedBytes.TrimEnd(token);
            if (protocolBytes == null) return null;
            return protocolBytes;
        }
    }
    class MagicNumbers
    {
        public static Decimal slopeAltitudeOrigin = -1111111111.1112131415161171819m;
        public static decimal SlopeAltitudeEnd = -2222222222.1112131415161171819m;
        public static decimal SlopeAbsPos = -3333333333.1112131415161171819m;
        public static decimal SlopeAbsPosEnd = -4444444444.1112131415161171819m;
        public static decimal SlopePos = -5555555555.1112131415161171819m;
        public static decimal ConvertToDecimalIsNull = -6666666666.1112131415161171819m;
        public static decimal ConvertToDecimalIsNotString = -7777777777.1112131415161171819m;
    }
}
